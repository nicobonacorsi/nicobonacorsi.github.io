from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from quant_projects.common import sha256_file, write_json
from quant_projects.distributional_volatility import run as run_distributional_volatility
from quant_projects.dro_allocation import run as run_dro_allocation


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "raw"
RESULTS = ROOT / "results"


def pct(value: float) -> str:
    return f"{100.0 * value:.2f}%"


def main() -> None:
    allocation = run_dro_allocation(
        DATA / "100_Portfolios_10x10_Daily.zip",
        RESULTS / "bootstrap_dro_allocation",
    )
    volatility = run_distributional_volatility(
        DATA / "spx_yahoo_1990_2026.json",
        DATA / "vix_history_1990_2026.csv",
        DATA / "spy_yahoo_1993_2026.json",
        DATA / "dgs3mo_2000_2026.csv",
        RESULTS / "distributional_volatility",
    )

    data_files = sorted(DATA.iterdir())
    manifest = {path.name: sha256_file(path) for path in data_files if path.is_file()}
    manifest_text = "".join(f"{digest}  data/raw/{name}\n" for name, digest in manifest.items())
    (ROOT / "DATA_MANIFEST.sha256").write_text(manifest_text)

    run_summary = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "data_sha256": manifest,
        "bootstrap_dro_allocation": allocation,
        "distributional_volatility": volatility,
    }
    write_json(RESULTS / "run_summary.json", run_summary)

    allocation_metrics = allocation["confirmation_metrics"]
    allocation_headline = allocation["confirmation_headline"]
    allocation_bootstrap = allocation["bootstrap_inference_vs_equal_weight"][
        "relative_volatility_reduction"
    ]
    allocation_lw_bootstrap = allocation["bootstrap_inference_vs_ledoit_wolf"][
        "relative_volatility_reduction"
    ]

    forecast = volatility["confirmation_forecast_metrics"]
    inference = volatility["forecast_loss_inference"]
    coverage = volatility["confirmation_upper_bound_coverage"]
    strategies = volatility["confirmation_strategy_metrics"]
    volatility_headline = volatility["confirmation_headline"]

    summary = f"""# Confirmation Results Summary

Generated directly from the code and immutable raw snapshots in this bundle.  The term **confirmation** is deliberate: an earlier, materially different project version had already been inspected on 2013–2026, so this bundle does not mislabel those dates as a pristine lockbox.

## Project 1 — Bootstrap-Calibrated Distributionally Robust Allocation

- Chosen on 2000–2012 only: `{allocation['selected_configuration']}`.
- Confirmation period: {allocation_metrics['bootstrap_dro']['start']} to {allocation_metrics['bootstrap_dro']['end']}.
- Annualized volatility: {pct(allocation_metrics['bootstrap_dro']['annualized_volatility'])} versus {pct(allocation_metrics['equal_weight']['annualized_volatility'])} for equal weight and {pct(allocation_metrics['ledoit_wolf']['annualized_volatility'])} for validation-selected Ledoit–Wolf GMV.
- Relative volatility reduction versus equal weight: {pct(allocation_headline['relative_volatility_reduction_vs_equal_weight'])}; paired 21-day block-bootstrap 95% interval [{pct(allocation_bootstrap['ci_95_low'])}, {pct(allocation_bootstrap['ci_95_high'])}].
- Relative volatility reduction versus Ledoit–Wolf: {pct(allocation_headline['relative_volatility_reduction_vs_ledoit_wolf'])}; 95% interval [{pct(allocation_lw_bootstrap['ci_95_low'])}, {pct(allocation_lw_bootstrap['ci_95_high'])}].  This improvement is statistically detectable in the paired bootstrap but economically small.
- CAGR: {pct(allocation_metrics['bootstrap_dro']['cagr'])}; Sharpe (zero cash): {allocation_metrics['bootstrap_dro']['sharpe_zero_cash']:.3f}; max drawdown: {pct(allocation_metrics['bootstrap_dro']['max_drawdown'])}; annual L1 turnover: {allocation_metrics['bootstrap_dro']['annualized_l1_turnover']:.2f}.
- Costs are 10 bps per dollar traded.  Estimator sensitivity covers 5/21/63-day blocks and 64–256 bootstrap replications per rebalance.

## Project 2 — Maturity-Safe Distributional Volatility Forecasting and Risk Control

- Base-model development: 2005–2008; calibration validation: 2009–2012; confirmation: 2013–2026.
- A bounded-loss Hedge ensemble uses a two-year rolling history and only labels whose complete 22-day targets matured before each quarterly refit.
- Confirmation QLIKE: {forecast['hedge_ensemble']['qlike']:.4f} versus {forecast['raw_vix_variance']['qlike']:.4f} for raw VIX variance ({pct(volatility_headline['qlike_improvement_vs_raw_vix'])} lower).  The HAC loss difference is not significant (p={inference['qlike_hedge_minus_vix']['p_value_two_sided']:.3f}).
- Confirmation log-RMSE: {forecast['hedge_ensemble']['log_rmse']:.4f} versus {forecast['raw_vix_variance']['log_rmse']:.4f} ({pct(volatility_headline['log_rmse_improvement_vs_raw_vix'])} lower); the squared-log-error HAC test gives p={inference['squared_log_error_hedge_minus_vix']['p_value_two_sided']:.2e}.
- The 22 interlaced calibration streams achieve {pct(coverage['empirical_upper_coverage'])} coverage over {coverage['n_evaluable_forecasts']} forecasts at a nominal 90% level.
- SPY total-return strategy after 1 bp per exposure change: CAGR {pct(strategies['distributional_bound']['cagr'])}, volatility {pct(strategies['distributional_bound']['annualized_volatility'])}, Sharpe over cash {strategies['distributional_bound']['sharpe_over_cash']:.3f}, max drawdown {pct(strategies['distributional_bound']['max_drawdown'])}, average exposure {strategies['distributional_bound']['average_exposure']:.3f}.
- SPY buy-and-hold returned more ({pct(strategies['buy_and_hold']['cagr'])} CAGR) but had {pct(strategies['buy_and_hold']['annualized_volatility'])} volatility and {pct(strategies['buy_and_hold']['max_drawdown'])} max drawdown.  A VIX rule matched on validation exposure had a better Sharpe and a slightly smaller drawdown; this negative result is retained.
- Against an attribution-only VIX series matched ex post to the same confirmation exposure, the distributional controller improved max drawdown by {pct(volatility_headline['max_drawdown_improvement_vs_expost_equal_exposure_vix_points'])}, but did not improve Sharpe.

## Integrity note

No headline number is hard-coded.  Delete `results/`, run `python run_all.py`, then run `python -m unittest discover -s tests -v`.  The emitted audits verify strictly past covariance windows, matured forecast labels, same-stream calibration, and non-overlapping 22-day targets within every interlaced stream.
"""
    (ROOT / "RESULTS_SUMMARY.md").write_text(summary)
    print(summary)


if __name__ == "__main__":
    main()
