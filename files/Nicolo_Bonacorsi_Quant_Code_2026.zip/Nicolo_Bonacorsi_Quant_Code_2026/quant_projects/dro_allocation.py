from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.covariance import LedoitWolf

from .common import (
    TRADING_DAYS,
    drawdown_series,
    paired_moving_block_bootstrap,
    performance_metrics,
    write_json,
)
from .robust_allocation import (
    PortfolioSimulation,
    equal_weight_targets,
    first_trading_day_positions,
    inverse_volatility_targets,
    load_ff25_aggregated_daily,
    project_capped_simplex,
    simulate_monthly_portfolio,
)


@dataclass
class CovarianceBundle:
    position: int
    sample: np.ndarray
    ledoit_wolf: np.ndarray
    bootstrap_upper: dict[float, np.ndarray]
    diagnostics: dict[str, float | int]


def nearest_psd(matrix: np.ndarray, floor: float = 1e-10) -> np.ndarray:
    symmetric = 0.5 * (np.asarray(matrix, dtype=float) + np.asarray(matrix, dtype=float).T)
    eigenvalues, eigenvectors = np.linalg.eigh(symmetric)
    scale = max(float(np.trace(symmetric) / len(symmetric)), 1e-12)
    eigenvalues = np.maximum(eigenvalues, floor * scale)
    return 0.5 * ((eigenvectors * eigenvalues) @ eigenvectors.T + ((eigenvectors * eigenvalues) @ eigenvectors.T).T)


def circular_block_indices(
    n_observations: int,
    block_length: int,
    replications: int,
    rng: np.random.Generator,
) -> np.ndarray:
    n_blocks = int(math.ceil(n_observations / block_length))
    starts = rng.integers(0, n_observations, size=(replications, n_blocks))
    offsets = np.arange(block_length)
    return ((starts[:, :, None] + offsets[None, None, :]) % n_observations).reshape(
        replications, -1
    )[:, :n_observations]


def bootstrap_directional_upper_covariances(
    window: np.ndarray,
    quantiles: tuple[float, ...],
    block_length: int,
    replications: int,
    seed: int,
) -> tuple[np.ndarray, dict[float, np.ndarray], dict[str, float | int]]:
    """Estimate a PSD upper risk envelope in the sample eigenbasis.

    Circular blocks preserve short-run dependence.  Every bootstrap covariance is
    projected into the eigenbasis estimated from the original trailing window.
    For each direction, the reported upper eigenvalue is the larger of the sample
    eigenvalue and the requested bootstrap quantile.  This is exactly the worst-case
    covariance for an eigenvector-preserving rectangular ambiguity set.
    """
    observations = np.asarray(window, dtype=float)
    centered = observations - observations.mean(axis=0, keepdims=True)
    sample = nearest_psd(np.cov(centered, rowvar=False, ddof=1))
    sample_eigenvalues, eigenvectors = np.linalg.eigh(sample)
    scores = centered @ eigenvectors
    rng = np.random.default_rng(seed)
    indices = circular_block_indices(len(scores), block_length, replications, rng)
    resampled = scores[indices]
    bootstrap_variances = resampled.var(axis=1, ddof=1)

    upper: dict[float, np.ndarray] = {}
    inflation: dict[float, float] = {}
    for quantile in quantiles:
        upper_eigenvalues = np.maximum(
            sample_eigenvalues,
            np.quantile(bootstrap_variances, quantile, axis=0),
        )
        covariance = (eigenvectors * upper_eigenvalues) @ eigenvectors.T
        upper[quantile] = nearest_psd(covariance)
        inflation[quantile] = float(np.trace(covariance) / np.trace(sample) - 1.0)

    standard_deviation = np.sqrt(np.diag(sample))
    correlation = sample / np.outer(standard_deviation, standard_deviation)
    correlation_eigenvalues = np.linalg.eigvalsh(0.5 * (correlation + correlation.T))
    aspect_ratio = observations.shape[1] / observations.shape[0]
    mp_edge = float((1.0 + math.sqrt(aspect_ratio)) ** 2)
    diagnostics: dict[str, float | int] = {
        "mp_edge": mp_edge,
        "n_eigenvalues_above_mp_edge": int(np.sum(correlation_eigenvalues > mp_edge)),
        "largest_correlation_eigenvalue": float(correlation_eigenvalues[-1]),
        "pc1_correlation_variance_share": float(
            correlation_eigenvalues[-1] / correlation_eigenvalues.sum()
        ),
        "sample_condition_number": float(np.linalg.cond(sample)),
        "bootstrap_replications": replications,
        "bootstrap_block_length": block_length,
    }
    diagnostics.update({f"trace_inflation_q{quantile:g}": value for quantile, value in inflation.items()})
    return sample, upper, diagnostics


def precompute_covariance_bundles(
    returns: pd.DataFrame,
    lookback: int,
    quantiles: tuple[float, ...],
    block_length: int = 21,
    replications: int = 48,
    earliest: str = "1998-01-01",
    seed: int = 20260716,
) -> dict[int, CovarianceBundle]:
    array = returns.to_numpy()
    positions = first_trading_day_positions(returns.index, earliest)
    positions = positions[positions >= lookback]
    bundles: dict[int, CovarianceBundle] = {}
    for position in positions:
        window = array[position - lookback : position]
        sample, upper, diagnostics = bootstrap_directional_upper_covariances(
            window,
            quantiles,
            block_length,
            replications,
            seed + int(position) * 1009 + lookback,
        )
        ledoit_wolf = nearest_psd(LedoitWolf(assume_centered=False).fit(window).covariance_)
        bundles[int(position)] = CovarianceBundle(
            position=int(position),
            sample=sample,
            ledoit_wolf=ledoit_wolf,
            bootstrap_upper=upper,
            diagnostics=diagnostics,
        )
    return bundles


def drift_weights(
    target: np.ndarray,
    returns: np.ndarray,
    start_position: int,
    end_position: int,
) -> np.ndarray:
    if end_position <= start_position:
        return target.copy()
    growth = np.prod(1.0 + returns[start_position:end_position], axis=0)
    pretrade = target * growth
    return pretrade / pretrade.sum()


def solve_turnover_aware_minimum_variance(
    covariance: np.ndarray,
    pretrade_weights: np.ndarray,
    cap: float,
    turnover_penalty: float,
) -> tuple[np.ndarray, dict[str, float | int | bool]]:
    """Solve the exact capped long-only convex quadratic program.

    The covariance is normalized by its average marginal variance.  Consequently,
    ``turnover_penalty`` is dimensionless and comparable across dates.
    """
    covariance = nearest_psd(covariance)
    n_assets = covariance.shape[0]
    scale = max(float(np.trace(covariance) / n_assets), 1e-12)
    normalized = covariance / scale
    reference = np.asarray(pretrade_weights, dtype=float)
    def objective(weights: np.ndarray) -> float:
        displacement = weights - reference
        return float(
            weights @ normalized @ weights
            + turnover_penalty * displacement @ displacement
        )

    def gradient(weights: np.ndarray) -> np.ndarray:
        return 2.0 * normalized @ weights + 2.0 * turnover_penalty * (weights - reference)

    # Specialized primal active-set solution for
    # min 1/2 w'Hw + f'w, 1'w=1, 0<=w<=cap.  At each iteration the free
    # variables solve the equality-constrained KKT system exactly.  Violating
    # primal bounds are added to the active set; active bounds with the wrong
    # multiplier sign are released.  This is orders of magnitude faster than a
    # generic optimizer in the validation grid and still solves the exact QP.
    hessian = 2.0 * (normalized + turnover_penalty * np.eye(n_assets))
    linear = -2.0 * turnover_penalty * reference
    lower: set[int] = set()
    upper: set[int] = set()
    weights = np.zeros(n_assets)
    lagrange = 0.0
    success = False
    iterations = 0
    tolerance = 2e-10
    all_indices = set(range(n_assets))
    for iterations in range(1, 4 * n_assets + 20):
        free = sorted(all_indices - lower - upper)
        weights[:] = 0.0
        if upper:
            weights[list(upper)] = cap
        remaining = 1.0 - cap * len(upper)
        if remaining < -tolerance or remaining > cap * len(free) + tolerance:
            raise RuntimeError("Infeasible active set in box-simplex QP.")
        if not free:
            if abs(remaining) <= tolerance:
                success = True
                break
            raise RuntimeError("No free variables in an infeasible active set.")

        free_array = np.asarray(free, dtype=int)
        active = sorted(lower | upper)
        right_hand_side = -linear[free_array]
        if active:
            active_array = np.asarray(active, dtype=int)
            right_hand_side -= hessian[np.ix_(free_array, active_array)] @ weights[active_array]
        kkt = np.block(
            [
                [hessian[np.ix_(free_array, free_array)], np.ones((len(free), 1))],
                [np.ones((1, len(free))), np.zeros((1, 1))],
            ]
        )
        solution = np.linalg.solve(kkt, np.r_[right_hand_side, remaining])
        weights[free_array] = solution[:-1]
        lagrange = float(solution[-1])

        below = [index for index in free if weights[index] < -tolerance]
        above = [index for index in free if weights[index] > cap + tolerance]
        if below or above:
            candidates: list[tuple[float, int, str]] = []
            if remaining <= cap * (len(free) - 1) + tolerance:
                candidates.extend((-weights[index], index, "lower") for index in below)
            next_remaining = remaining - cap
            if (
                next_remaining >= -tolerance
                and next_remaining <= cap * (len(free) - 1) + tolerance
            ):
                candidates.extend((weights[index] - cap, index, "upper") for index in above)
            if not candidates:
                raise RuntimeError("No feasible bound activation in box-simplex QP.")
            _, index, bound = max(candidates)
            if bound == "lower":
                lower.add(index)
            else:
                upper.add(index)
            continue

        lagrangian_gradient = hessian @ weights + linear + lagrange
        release_candidates: list[tuple[float, int, str]] = []
        release_candidates.extend(
            (-lagrangian_gradient[index], index, "lower")
            for index in lower
            if lagrangian_gradient[index] < -tolerance
        )
        release_candidates.extend(
            (lagrangian_gradient[index], index, "upper")
            for index in upper
            if lagrangian_gradient[index] > tolerance
        )
        if release_candidates:
            _, index, bound = max(release_candidates)
            (lower if bound == "lower" else upper).remove(index)
            continue
        success = True
        break
    if not success:
        raise RuntimeError("Active-set QP solver did not converge.")
    weights[np.abs(weights) < 1e-12] = 0.0
    weights /= weights.sum()
    if weights.min() < -1e-9 or weights.max() > cap + 1e-8:
        raise AssertionError("Optimizer returned infeasible weights.")
    return weights, {
        "optimizer_success": success,
        "optimizer_iterations": iterations,
        "objective": objective(weights),
        "predicted_daily_variance": float(weights @ covariance @ weights),
        "pretrade_l1_change": float(np.abs(weights - reference).sum()),
    }


def build_covariance_targets(
    returns: pd.DataFrame,
    bundles: dict[int, CovarianceBundle],
    estimator: str,
    cap: float,
    turnover_penalty: float,
    quantile: float | None = None,
) -> tuple[dict[int, np.ndarray], pd.DataFrame]:
    array = returns.to_numpy()
    previous_target = np.ones(returns.shape[1]) / returns.shape[1]
    previous_position: int | None = None
    targets: dict[int, np.ndarray] = {}
    rows: list[dict[str, Any]] = []
    for position, bundle in sorted(bundles.items()):
        pretrade = (
            previous_target.copy()
            if previous_position is None
            else drift_weights(previous_target, array, previous_position, position)
        )
        if estimator == "sample":
            covariance = bundle.sample
        elif estimator == "ledoit_wolf":
            covariance = bundle.ledoit_wolf
        elif estimator == "bootstrap_upper":
            if quantile is None:
                raise ValueError("Bootstrap estimator requires a quantile.")
            covariance = bundle.bootstrap_upper[quantile]
        else:
            raise ValueError(f"Unknown estimator: {estimator}")
        target, diagnostics = solve_turnover_aware_minimum_variance(
            covariance,
            pretrade,
            cap,
            turnover_penalty,
        )
        targets[position] = target
        rows.append(
            {
                "rebalance_date": returns.index[position],
                "position": position,
                "estimator": estimator,
                "quantile": quantile,
                "cap": cap,
                "turnover_penalty": turnover_penalty,
                **diagnostics,
            }
        )
        previous_target = target
        previous_position = position
    return targets, pd.DataFrame(rows)


def metrics_for_period(
    simulation: PortfolioSimulation,
    start: str,
    end: str,
) -> dict[str, float | int | str]:
    return performance_metrics(
        simulation.net_returns.loc[start:end],
        turnover=simulation.l1_turnover.loc[start:end],
    )


def select_method(
    returns: pd.DataFrame,
    bundle_by_lookback: dict[int, dict[int, CovarianceBundle]],
    estimator: str,
    quantiles: tuple[float, ...],
    caps: tuple[float, ...],
    turnover_penalties: tuple[float, ...],
    cost_rate: float,
    validation_start: str,
    validation_end: str,
) -> tuple[pd.DataFrame, dict[tuple[Any, ...], dict[int, np.ndarray]]]:
    rows: list[dict[str, Any]] = []
    cache: dict[tuple[Any, ...], dict[int, np.ndarray]] = {}
    method_quantiles: tuple[float | None, ...] = quantiles if estimator == "bootstrap_upper" else (None,)
    validation_end_timestamp = pd.Timestamp(validation_end)
    for lookback, full_bundles in bundle_by_lookback.items():
        # Model selection never needs post-validation targets.  Restricting the
        # optimizer path here is both faster and makes the separation explicit.
        bundles = {
            position: bundle
            for position, bundle in full_bundles.items()
            if returns.index[position] <= validation_end_timestamp
        }
        for quantile in method_quantiles:
            for cap in caps:
                for penalty in turnover_penalties:
                    key = (estimator, lookback, quantile, cap, penalty)
                    targets, _ = build_covariance_targets(
                        returns,
                        bundles,
                        estimator,
                        cap,
                        penalty,
                        quantile,
                    )
                    cache[key] = targets
                    simulation = simulate_monthly_portfolio(returns, targets, cost_rate)
                    metrics = metrics_for_period(simulation, validation_start, validation_end)
                    rows.append(
                        {
                            "estimator": estimator,
                            "lookback_days": lookback,
                            "bootstrap_quantile": quantile,
                            "maximum_weight": cap,
                            "turnover_penalty": penalty,
                            "validation_volatility": metrics["annualized_volatility"],
                            "validation_sharpe": metrics["sharpe_zero_cash"],
                            "validation_cagr": metrics["cagr"],
                            "validation_max_drawdown": metrics["max_drawdown"],
                            "validation_l1_turnover": metrics["annualized_l1_turnover"],
                        }
                    )
    selection = pd.DataFrame(rows).sort_values(
        ["validation_volatility", "validation_l1_turnover", "lookback_days"],
        ignore_index=True,
    )
    return selection, cache


def winner_key(row: pd.Series) -> tuple[Any, ...]:
    quantile = None if pd.isna(row.bootstrap_quantile) else float(row.bootstrap_quantile)
    return (
        str(row.estimator),
        int(row.lookback_days),
        quantile,
        float(row.maximum_weight),
        float(row.turnover_penalty),
    )


def risk_calibration(
    returns: pd.DataFrame,
    bundles: dict[int, CovarianceBundle],
    targets: dict[int, np.ndarray],
    estimator: str,
    quantile: float | None,
) -> pd.DataFrame:
    array = returns.to_numpy()
    positions = sorted(set(bundles).intersection(targets))
    rows: list[dict[str, Any]] = []
    for index, position in enumerate(positions[:-1]):
        next_position = positions[index + 1]
        bundle = bundles[position]
        if estimator == "bootstrap_upper":
            covariance = bundle.bootstrap_upper[float(quantile)]
        elif estimator == "ledoit_wolf":
            covariance = bundle.ledoit_wolf
        else:
            covariance = bundle.sample
        weights = targets[position]
        predicted = float(math.sqrt(max(weights @ covariance @ weights, 0.0) * TRADING_DAYS))
        realized_returns = array[position:next_position] @ weights
        realized = float(realized_returns.std(ddof=1) * math.sqrt(TRADING_DAYS))
        rows.append(
            {
                "rebalance_date": returns.index[position],
                "next_rebalance_date": returns.index[next_position],
                "estimator": estimator,
                "predicted_annualized_volatility": predicted,
                "next_month_realized_annualized_volatility": realized,
                "realized_to_predicted_ratio": realized / predicted,
            }
        )
    return pd.DataFrame(rows)


def make_plots(
    output_dir: Path,
    simulations: dict[str, PortfolioSimulation],
    selected_diagnostics: pd.DataFrame,
    risk_calibration_frame: pd.DataFrame,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    labels = {
        "bootstrap_dro": "Bootstrap-DRO",
        "ledoit_wolf": "Ledoit–Wolf GMV",
        "sample_gmv": "Sample GMV",
        "equal_weight": "Equal weight",
    }
    test_returns = {
        name: simulations[name].net_returns.loc["2013":].dropna()
        for name in labels
    }
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 7.0), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
    for name, label in labels.items():
        series = test_returns[name]
        axes[0].plot((1.0 + series).cumprod(), label=label, linewidth=1.35)
        axes[1].plot(drawdown_series(series), label=label, linewidth=1.1)
    axes[0].set_title("Confirmation sample: public 25-portfolio allocation (2013–2026)")
    axes[0].set_ylabel("Growth of $1")
    axes[0].legend(ncol=2, frameon=False)
    axes[0].grid(alpha=0.2)
    axes[1].set_ylabel("Drawdown")
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "confirmation_wealth_and_drawdown.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10.5, 4.6))
    for name, label in labels.items():
        rolling = test_returns[name].rolling(63).std() * math.sqrt(TRADING_DAYS)
        ax.plot(rolling, label=label, linewidth=1.15)
    ax.set_title("63-day realized volatility")
    ax.set_ylabel("Annualized volatility")
    ax.legend(ncol=2, frameon=False)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "confirmation_rolling_volatility.png", dpi=180)
    plt.close(fig)

    diagnostic = selected_diagnostics.loc[selected_diagnostics["rebalance_date"] >= "2013-01-01"]
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 6.5), sharex=True)
    axes[0].plot(diagnostic["rebalance_date"], diagnostic["n_eigenvalues_above_mp_edge"], linewidth=1.1)
    axes[0].set_ylabel("MP signal directions")
    axes[0].grid(alpha=0.2)
    axes[1].plot(diagnostic["rebalance_date"], diagnostic["pc1_correlation_variance_share"], linewidth=1.1)
    axes[1].set_ylabel("PC1 share")
    axes[1].grid(alpha=0.2)
    axes[0].set_title("Correlation-spectrum regime diagnostics")
    fig.tight_layout()
    fig.savefig(output_dir / "rmt_regime_diagnostics.png", dpi=180)
    plt.close(fig)

    calibration = risk_calibration_frame.loc[risk_calibration_frame["rebalance_date"] >= "2013-01-01"]
    fig, ax = plt.subplots(figsize=(7.4, 5.4))
    ax.scatter(
        calibration["predicted_annualized_volatility"],
        calibration["next_month_realized_annualized_volatility"],
        s=16,
        alpha=0.55,
    )
    limit = float(
        max(
            calibration["predicted_annualized_volatility"].max(),
            calibration["next_month_realized_annualized_volatility"].max(),
        )
    )
    ax.plot([0.0, limit], [0.0, limit], linestyle="--", color="black", linewidth=1.0)
    ax.set_xlabel("Predicted annualized volatility")
    ax.set_ylabel("Next-month realized annualized volatility")
    ax.set_title("Ex-ante risk calibration")
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "risk_forecast_calibration.png", dpi=180)
    plt.close(fig)


def run(data_path: Path, output_dir: Path) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    returns = load_ff25_aggregated_daily(data_path)
    cost_rate = 10.0 / 10_000.0
    validation_start, validation_end = "2000-01-01", "2012-12-31"
    confirmation_start, confirmation_end = "2013-01-01", str(returns.index[-1].date())
    lookbacks = (252, 504)
    quantiles = (0.75, 0.90, 0.95)
    caps = (0.10, 0.20)
    turnover_penalties = (0.0, 0.5, 2.0)
    block_length = 21
    bootstrap_replications = 128

    bundle_by_lookback = {
        lookback: precompute_covariance_bundles(
            returns,
            lookback,
            quantiles,
            block_length=block_length,
            replications=bootstrap_replications,
        )
        for lookback in lookbacks
    }

    all_selection: list[pd.DataFrame] = []
    target_caches: dict[str, dict[tuple[Any, ...], dict[int, np.ndarray]]] = {}
    for estimator in ("bootstrap_upper", "ledoit_wolf", "sample"):
        selection, cache = select_method(
            returns,
            bundle_by_lookback,
            estimator,
            quantiles,
            caps,
            turnover_penalties,
            cost_rate,
            validation_start,
            validation_end,
        )
        all_selection.append(selection)
        target_caches[estimator] = cache
    selection = pd.concat(
        [frame.dropna(axis=1, how="all") for frame in all_selection],
        ignore_index=True,
    )
    winners = {
        estimator: selection.loc[selection["estimator"] == estimator]
        .sort_values(["validation_volatility", "validation_l1_turnover"])
        .iloc[0]
        for estimator in ("bootstrap_upper", "ledoit_wolf", "sample")
    }
    configurations = {name: winner_key(row) for name, row in winners.items()}

    simulations: dict[str, PortfolioSimulation] = {}
    selected_target_map: dict[str, dict[int, np.ndarray]] = {}
    name_map = {
        "bootstrap_upper": "bootstrap_dro",
        "ledoit_wolf": "ledoit_wolf",
        "sample": "sample_gmv",
    }
    for estimator, config in configurations.items():
        _, selected_lookback, selected_quantile, selected_cap, selected_penalty = config
        targets, _ = build_covariance_targets(
            returns,
            bundle_by_lookback[selected_lookback],
            estimator,
            selected_cap,
            selected_penalty,
            selected_quantile,
        )
        selected_target_map[name_map[estimator]] = targets
        simulations[name_map[estimator]] = simulate_monthly_portfolio(returns, targets, cost_rate)
    simulations["equal_weight"] = simulate_monthly_portfolio(
        returns,
        equal_weight_targets(returns),
        cost_rate,
    )
    simulations["inverse_volatility"] = simulate_monthly_portfolio(
        returns,
        inverse_volatility_targets(returns),
        cost_rate,
    )

    validation_metrics = {
        name: metrics_for_period(simulation, validation_start, validation_end)
        for name, simulation in simulations.items()
    }
    confirmation_metrics = {
        name: metrics_for_period(simulation, confirmation_start, confirmation_end)
        for name, simulation in simulations.items()
    }

    bootstrap_vs_equal = paired_moving_block_bootstrap(
        simulations["bootstrap_dro"].net_returns.loc[confirmation_start:confirmation_end],
        simulations["equal_weight"].net_returns.loc[confirmation_start:confirmation_end],
    )
    bootstrap_vs_ledoit = paired_moving_block_bootstrap(
        simulations["bootstrap_dro"].net_returns.loc[confirmation_start:confirmation_end],
        simulations["ledoit_wolf"].net_returns.loc[confirmation_start:confirmation_end],
    )

    dro_config = configurations["bootstrap_upper"]
    _, dro_lookback, dro_quantile, dro_cap, dro_penalty = dro_config
    cost_rows: list[dict[str, Any]] = []
    dro_targets = selected_target_map["bootstrap_dro"]
    for cost_bps in (0.0, 5.0, 10.0, 25.0, 50.0):
        simulation = simulate_monthly_portfolio(returns, dro_targets, cost_bps / 10_000.0)
        cost_rows.append(
            {
                "cost_bps_per_dollar_traded": cost_bps,
                **metrics_for_period(simulation, confirmation_start, confirmation_end),
            }
        )
    cost_sensitivity = pd.DataFrame(cost_rows)

    estimator_sensitivity_rows: list[dict[str, Any]] = []
    for sensitivity_block, sensitivity_replications in (
        (5, 64),
        (21, 64),
        (21, 128),
        (21, 256),
        (63, 64),
    ):
        if sensitivity_block == block_length and sensitivity_replications == bootstrap_replications:
            sensitivity_targets = dro_targets
        else:
            sensitivity_bundles = precompute_covariance_bundles(
                returns,
                dro_lookback,
                (float(dro_quantile),),
                block_length=sensitivity_block,
                replications=sensitivity_replications,
            )
            sensitivity_targets, _ = build_covariance_targets(
                returns,
                sensitivity_bundles,
                "bootstrap_upper",
                dro_cap,
                dro_penalty,
                float(dro_quantile),
            )
        sensitivity_simulation = simulate_monthly_portfolio(
            returns,
            sensitivity_targets,
            cost_rate,
        )
        sensitivity_metrics = metrics_for_period(
            sensitivity_simulation,
            confirmation_start,
            confirmation_end,
        )
        primary_weights = simulations["bootstrap_dro"].target_weights.loc[
            confirmation_start:confirmation_end
        ]
        sensitivity_weights = sensitivity_simulation.target_weights.reindex(primary_weights.index)
        estimator_sensitivity_rows.append(
            {
                "bootstrap_block_length": sensitivity_block,
                "bootstrap_replications_per_rebalance": sensitivity_replications,
                **sensitivity_metrics,
                "mean_l1_weight_distance_from_primary": float(
                    np.abs(sensitivity_weights - primary_weights).sum(axis=1).mean()
                ),
            }
        )
    estimator_sensitivity = pd.DataFrame(estimator_sensitivity_rows)

    subperiod_rows: list[dict[str, Any]] = []
    for period, start, end in (
        ("2013_2019", "2013-01-01", "2019-12-31"),
        ("2020_2026", "2020-01-01", confirmation_end),
    ):
        for name, simulation in simulations.items():
            subperiod_rows.append(
                {"period": period, "strategy": name, **metrics_for_period(simulation, start, end)}
            )
    subperiod_metrics = pd.DataFrame(subperiod_rows)

    dro_bundles = bundle_by_lookback[dro_lookback]
    risk_dro = risk_calibration(
        returns,
        dro_bundles,
        dro_targets,
        "bootstrap_upper",
        float(dro_quantile),
    )
    lw_config = configurations["ledoit_wolf"]
    lw_bundles = bundle_by_lookback[lw_config[1]]
    risk_lw = risk_calibration(
        returns,
        lw_bundles,
        selected_target_map["ledoit_wolf"],
        "ledoit_wolf",
        None,
    )
    risk_frame = pd.concat([risk_dro, risk_lw], ignore_index=True)

    diagnostics_rows: list[dict[str, Any]] = []
    for position, bundle in sorted(dro_bundles.items()):
        diagnostics_rows.append(
            {
                "rebalance_date": returns.index[position],
                "training_start": returns.index[position - dro_lookback],
                "training_end": returns.index[position - 1],
                "strictly_past_training": bool(returns.index[position - 1] < returns.index[position]),
                **bundle.diagnostics,
            }
        )
    diagnostics = pd.DataFrame(diagnostics_rows)

    test_daily = pd.DataFrame(index=returns.loc[confirmation_start:confirmation_end].index)
    for name, simulation in simulations.items():
        test_daily[f"{name}_net_return"] = simulation.net_returns
        test_daily[f"{name}_turnover"] = simulation.l1_turnover

    selection.sort_values(["estimator", "validation_volatility"]).to_csv(
        output_dir / "validation_selection_grid.csv", index=False
    )
    pd.DataFrame(validation_metrics).T.to_csv(output_dir / "validation_metrics.csv")
    pd.DataFrame(confirmation_metrics).T.to_csv(output_dir / "confirmation_metrics.csv")
    cost_sensitivity.to_csv(output_dir / "cost_sensitivity.csv", index=False)
    estimator_sensitivity.to_csv(output_dir / "bootstrap_estimator_sensitivity.csv", index=False)
    subperiod_metrics.to_csv(output_dir / "subperiod_metrics.csv", index=False)
    risk_frame.to_csv(output_dir / "risk_forecast_calibration.csv", index=False)
    diagnostics.to_csv(output_dir / "covariance_and_training_audit.csv", index=False)
    test_daily.to_csv(output_dir / "confirmation_daily_returns.csv", index_label="date")
    simulations["bootstrap_dro"].target_weights.to_csv(
        output_dir / "selected_target_weights.csv", index_label="rebalance_date"
    )
    make_plots(output_dir, simulations, diagnostics, risk_dro)

    dro_test = confirmation_metrics["bootstrap_dro"]
    equal_test = confirmation_metrics["equal_weight"]
    lw_test = confirmation_metrics["ledoit_wolf"]
    headline = {
        "relative_volatility_reduction_vs_equal_weight": float(
            1.0 - dro_test["annualized_volatility"] / equal_test["annualized_volatility"]
        ),
        "relative_volatility_reduction_vs_ledoit_wolf": float(
            1.0 - dro_test["annualized_volatility"] / lw_test["annualized_volatility"]
        ),
        "sharpe_difference_vs_equal_weight": float(
            dro_test["sharpe_zero_cash"] - equal_test["sharpe_zero_cash"]
        ),
        "max_drawdown_improvement_vs_equal_weight_points": float(
            dro_test["max_drawdown"] - equal_test["max_drawdown"]
        ),
    }
    selected_configuration = {
        "lookback_days": dro_lookback,
        "bootstrap_quantile": dro_quantile,
        "maximum_weight": dro_cap,
        "turnover_penalty": dro_penalty,
        "bootstrap_block_length": block_length,
        "bootstrap_replications_per_rebalance": bootstrap_replications,
    }
    results: dict[str, Any] = {
        "project": "Bootstrap-Calibrated Distributionally Robust Allocation",
        "data": {
            "source_file": data_path.name,
            "start": str(returns.index[0].date()),
            "end": str(returns.index[-1].date()),
            "n_daily_observations": int(len(returns)),
            "n_portfolios": int(returns.shape[1]),
        },
        "research_contribution": (
            "An eigenvector-preserving covariance ambiguity set is calibrated from circular-block "
            "bootstrap dispersion; its upper directional variances enter an exact capped, "
            "optionally displacement-regularized convex allocation problem."
        ),
        "protocol": {
            "validation_period": [validation_start, validation_end],
            "confirmation_period": [confirmation_start, confirmation_end],
            "selection_objective": "minimum validation net annualized volatility",
            "candidate_lookbacks_days": list(lookbacks),
            "candidate_bootstrap_quantiles": list(quantiles),
            "candidate_weight_caps": list(caps),
            "candidate_turnover_penalties": list(turnover_penalties),
            "transaction_cost": "10 bps times full L1 change in portfolio weights",
            "benchmark_selection": "Sample and Ledoit-Wolf GMV each select their own lookback, cap, and turnover penalty on the same validation period.",
        },
        "selected_configuration": selected_configuration,
        "selected_benchmark_configurations": {
            "ledoit_wolf": {
                "lookback_days": lw_config[1],
                "maximum_weight": lw_config[3],
                "turnover_penalty": lw_config[4],
            },
            "sample": {
                "lookback_days": configurations["sample"][1],
                "maximum_weight": configurations["sample"][3],
                "turnover_penalty": configurations["sample"][4],
            },
        },
        "validation_metrics": validation_metrics,
        "confirmation_metrics": confirmation_metrics,
        "confirmation_headline": headline,
        "bootstrap_inference_vs_equal_weight": bootstrap_vs_equal,
        "bootstrap_inference_vs_ledoit_wolf": bootstrap_vs_ledoit,
        "risk_calibration": {
            "bootstrap_dro_mean_realized_to_predicted_ratio": float(
                risk_dro.loc[risk_dro["rebalance_date"] >= confirmation_start, "realized_to_predicted_ratio"].mean()
            ),
            "ledoit_wolf_mean_realized_to_predicted_ratio": float(
                risk_lw.loc[risk_lw["rebalance_date"] >= confirmation_start, "realized_to_predicted_ratio"].mean()
            ),
        },
        "limitations": [
            "The inputs are academic characteristic portfolios rather than directly traded securities.",
            "The ambiguity set preserves the sample eigenvectors and therefore does not span eigenvector rotation risk.",
            "Bootstrap replications are intentionally modest for reproducibility; the supplied sensitivity tables should be consulted before deployment.",
            "Published portfolio returns cannot support constituent-level spread, market-impact, or capacity estimates.",
            "The 2013–2026 period is labelled confirmation rather than pristine lockbox because an earlier project version was already examined on these dates.",
        ],
    }
    write_json(output_dir / "results.json", results)
    return results
