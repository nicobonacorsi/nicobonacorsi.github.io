from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

from .common import (
    TRADING_DAYS,
    drawdown_series,
    newey_west_mean_test,
    paired_moving_block_bootstrap,
    performance_metrics,
    write_json,
)


HORIZON = 22


@dataclass
class StrategySimulation:
    returns: pd.Series
    turnover: pd.Series
    exposure: pd.Series


def load_spx_vix(spx_json: Path, vix_csv: Path) -> pd.DataFrame:
    payload = json.loads(spx_json.read_text())
    result = payload["chart"]["result"][0]
    dates = (
        pd.to_datetime(result["timestamp"], unit="s", utc=True)
        .tz_convert("America/New_York")
        .tz_localize(None)
        .normalize()
    )
    quote = result["indicators"]["quote"][0]
    spx = pd.DataFrame(quote, index=dates)
    spx["adjclose"] = result["indicators"]["adjclose"][0]["adjclose"]
    spx.index.name = "date"

    vix = pd.read_csv(vix_csv)
    vix["date"] = pd.to_datetime(vix["DATE"])
    vix = vix.set_index("date")["CLOSE"].astype(float).rename("vix")
    joined = spx.join(vix, how="inner").sort_index()
    if joined[["adjclose", "vix"]].isna().any().any():
        raise AssertionError("Aligned SPX/VIX closes must be complete.")
    return joined


def build_forecast_frame(market: pd.DataFrame) -> pd.DataFrame:
    log_return = np.log(market["adjclose"]).diff()
    simple_return = market["adjclose"].pct_change()
    implied_variance = (market["vix"] / 100.0) ** 2
    rv5 = TRADING_DAYS * log_return.pow(2).rolling(5).mean()
    rv22 = TRADING_DAYS * log_return.pow(2).rolling(22).mean()
    rv66 = TRADING_DAYS * log_return.pow(2).rolling(66).mean()
    future_squares = pd.concat([log_return.shift(-step).pow(2) for step in range(1, HORIZON + 1)], axis=1)
    future_variance = TRADING_DAYS * future_squares.mean(axis=1, skipna=False)
    target_end = pd.Series(market.index.to_numpy(), index=market.index).shift(-HORIZON)

    frame = pd.DataFrame(
        {
            "log_iv": np.log(implied_variance),
            "log_rv5": np.log(rv5),
            "log_rv22": np.log(rv22),
            "log_rv66": np.log(rv66),
            "negative_return_5d": -log_return.rolling(5).sum().clip(upper=0.0),
            "log_vix_change_5d": np.log(market["vix"]).diff(5),
            "future_variance": future_variance,
            "log_future_variance": np.log(future_variance),
            "target_end": target_end,
            "implied_variance": implied_variance,
            "trailing_variance_22d": rv22,
            "vix": market["vix"],
            "simple_return": simple_return,
            "next_simple_return": simple_return.shift(-1),
        }
    )
    feature_columns = [
        "log_iv",
        "log_rv5",
        "log_rv22",
        "log_rv66",
        "negative_return_5d",
        "log_vix_change_5d",
    ]
    frame = frame.dropna(subset=feature_columns)
    return frame


def quarterly_expanding_predictions(
    frame: pd.DataFrame,
    feature_columns: list[str],
    alpha: float,
    smearing: bool,
    prediction_start: str = "2005-01-01",
) -> tuple[pd.Series, pd.DataFrame]:
    prediction_index = frame.loc[prediction_start:].index
    prediction = pd.Series(np.nan, index=frame.index, name="point_forecast")
    audit_rows: list[dict[str, Any]] = []
    grouped = pd.Series(prediction_index, index=prediction_index).groupby(prediction_index.to_period("Q"))
    for _, group in grouped:
        dates = pd.DatetimeIndex(group.to_numpy())
        refit_date = dates[0]
        eligible = frame[
            frame["log_future_variance"].notna()
            & frame["target_end"].notna()
            & (frame["target_end"] < refit_date)
        ]
        if len(eligible) < 500:
            continue
        mean = eligible[feature_columns].mean()
        scale = eligible[feature_columns].std(ddof=1)
        train_x = (eligible[feature_columns] - mean) / scale
        model = Ridge(alpha=alpha).fit(train_x, eligible["log_future_variance"])
        fitted = model.predict(train_x)
        smear = float(np.mean(np.exp(eligible["log_future_variance"].to_numpy() - fitted))) if smearing else 1.0
        test_x = (frame.loc[dates, feature_columns] - mean) / scale
        prediction.loc[dates] = np.exp(model.predict(test_x)) * smear
        audit_rows.append(
            {
                "refit_date": refit_date,
                "prediction_period_end": dates[-1],
                "training_origin_start": eligible.index[0],
                "training_origin_end": eligible.index[-1],
                "latest_training_target_end": eligible["target_end"].max(),
                "n_training_labels": len(eligible),
                "all_training_labels_matured": bool(eligible["target_end"].max() < refit_date),
                "alpha": alpha,
                "smearing": smearing,
                "n_features": len(feature_columns),
            }
        )
    return prediction.clip(lower=0.002, upper=3.0), pd.DataFrame(audit_rows)


def qlike_loss(actual: np.ndarray, forecast: np.ndarray) -> np.ndarray:
    ratio = np.asarray(actual) / np.asarray(forecast)
    return ratio - np.log(ratio) - 1.0


def forecast_metrics(frame: pd.DataFrame, forecast: pd.Series, start: str, end: str) -> dict[str, float | int]:
    sample = pd.DataFrame(
        {"actual": frame["future_variance"], "forecast": forecast}, index=frame.index
    ).loc[start:end].dropna()
    log_error = np.log(sample["actual"]) - np.log(sample["forecast"])
    return {
        "n_forecasts": int(len(sample)),
        "qlike": float(qlike_loss(sample["actual"].to_numpy(), sample["forecast"].to_numpy()).mean()),
        "log_rmse": float(np.sqrt(np.mean(log_error.to_numpy() ** 2))),
        "log_mae": float(np.mean(np.abs(log_error.to_numpy()))),
        "level_correlation": float(sample.corr().iloc[0, 1]),
    }


def rolling_upper_bound(
    frame: pd.DataFrame,
    point_forecast: pd.Series,
    quantile: float = 0.90,
    calibration_window: int = 756,
    minimum_calibration: int = 252,
) -> tuple[pd.Series, pd.DataFrame]:
    upper = pd.Series(np.nan, index=frame.index, name="upper_predictive_bound")
    audit_rows: list[dict[str, Any]] = []
    for date in frame.loc["2005-01-01":].index:
        eligible = frame[
            frame["log_future_variance"].notna()
            & frame["target_end"].notna()
            & (frame["target_end"] < date)
            & point_forecast.notna()
        ].tail(calibration_window)
        if len(eligible) < minimum_calibration or not np.isfinite(point_forecast.loc[date]):
            continue
        residual = eligible["log_future_variance"] - np.log(point_forecast.loc[eligible.index])
        residual_quantile = float(residual.quantile(quantile))
        upper.loc[date] = float(point_forecast.loc[date] * math.exp(residual_quantile))
        audit_rows.append(
            {
                "forecast_date": date,
                "calibration_origin_start": eligible.index[0],
                "calibration_origin_end": eligible.index[-1],
                "latest_calibration_target_end": eligible["target_end"].max(),
                "n_calibration_residuals": len(eligible),
                "residual_quantile": residual_quantile,
                "all_calibration_labels_matured": bool(eligible["target_end"].max() < date),
            }
        )
    return upper, pd.DataFrame(audit_rows)


def simulate_exposure_strategy(
    exposure: pd.Series,
    next_simple_return: pd.Series,
    cost_bps: float,
) -> StrategySimulation:
    aligned = pd.concat(
        [exposure.rename("exposure"), next_simple_return.rename("next_return")], axis=1
    ).dropna()
    turnover = aligned["exposure"].diff().abs().fillna(0.0)
    strategy_return = aligned["exposure"] * aligned["next_return"] - cost_bps / 10_000.0 * turnover
    strategy_return.name = "strategy_return"
    return StrategySimulation(strategy_return, turnover, aligned["exposure"])


def _strategy_metrics(sim: StrategySimulation, start: str, end: str) -> dict[str, float | int | str]:
    return performance_metrics(
        sim.returns.loc[start:end],
        turnover=sim.turnover.loc[start:end],
        exposure=sim.exposure.loc[start:end],
    )


def _coverage(frame: pd.DataFrame, upper: pd.Series, start: str, end: str) -> dict[str, float | int]:
    sample = pd.concat(
        [frame["future_variance"].rename("actual"), upper.rename("upper")], axis=1
    ).loc[start:end].dropna()
    return {
        "n_evaluable_forecasts": int(len(sample)),
        "empirical_upper_coverage": float((sample["actual"] <= sample["upper"]).mean()),
        "mean_upper_to_point_ratio": float((sample["upper"] / frame.loc[sample.index, "point_forecast"]).mean()),
    }


def _make_plots(
    output_dir: Path,
    frame: pd.DataFrame,
    simulations: dict[str, StrategySimulation],
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    common_index = simulations["uncertainty_bound"].returns.loc["2013":].index
    labels = {
        "buy_and_hold": "SPX buy-and-hold",
        "fixed_validation_exposure": "Fixed validation exposure",
        "vix_target": "VIX risk target",
        "uncertainty_bound": "Uncertainty-bound target",
    }
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 7.0), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
    for key, label in labels.items():
        ret = simulations[key].returns.reindex(common_index).dropna()
        axes[0].plot((1.0 + ret).cumprod(), label=label, linewidth=1.4)
        axes[1].plot(drawdown_series(ret), label=label, linewidth=1.15)
    axes[0].set_title("Locked economic test (2013–2026)")
    axes[0].set_ylabel("Growth of $1")
    axes[0].legend(ncol=2, frameon=False)
    axes[0].grid(alpha=0.2)
    axes[1].set_ylabel("Drawdown")
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "test_wealth_and_drawdown.png", dpi=180)
    plt.close(fig)

    forecast = frame.loc["2020":].dropna(subset=["future_variance", "point_forecast", "upper_predictive_bound"])
    fig, ax = plt.subplots(figsize=(10.5, 4.8))
    ax.plot(np.sqrt(forecast["future_variance"]), label="Future 22-day realized volatility", linewidth=1.2)
    ax.plot(np.sqrt(forecast["point_forecast"]), label="Point forecast", linewidth=1.0)
    ax.plot(np.sqrt(forecast["upper_predictive_bound"]), label="90% residual-calibrated upper bound", linewidth=1.0)
    ax.set_title("Volatility forecast and uncertainty bound")
    ax.set_ylabel("Annualized volatility")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "forecast_and_upper_bound.png", dpi=180)
    plt.close(fig)

    crisis = frame.loc["2019-01-01":"2021-12-31"]
    exposure = simulations["uncertainty_bound"].exposure.reindex(crisis.index)
    fig, ax1 = plt.subplots(figsize=(10.5, 4.8))
    ax1.plot(exposure, color="tab:blue", label="Risk exposure", linewidth=1.3)
    ax1.set_ylabel("SPX exposure", color="tab:blue")
    ax2 = ax1.twinx()
    ax2.plot(crisis["vix"], color="tab:red", alpha=0.7, label="VIX", linewidth=1.0)
    ax2.set_ylabel("VIX", color="tab:red")
    ax1.set_title("Exposure response around the COVID volatility shock")
    ax1.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "covid_exposure_response.png", dpi=180)
    plt.close(fig)

    coverage_flag = (
        frame["future_variance"] <= frame["upper_predictive_bound"]
    ).where(frame[["future_variance", "upper_predictive_bound"]].notna().all(axis=1))
    rolling = coverage_flag.loc["2013":].rolling(252, min_periods=126).mean()
    fig, ax = plt.subplots(figsize=(10.5, 4.3))
    ax.plot(rolling, linewidth=1.2)
    ax.axhline(0.90, color="black", linestyle="--", linewidth=1.0, label="Nominal 90%")
    ax.set_ylim(0.60, 1.01)
    ax.set_ylabel("Rolling empirical coverage")
    ax.set_title("One-year coverage of the upper volatility bound")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "test_rolling_coverage.png", dpi=180)
    plt.close(fig)


def run(spx_json: Path, vix_csv: Path, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    market = load_spx_vix(spx_json, vix_csv)
    frame = build_forecast_frame(market)
    validation_start, validation_end = "2005-01-01", "2012-12-31"
    test_start, test_end = "2013-01-01", str(market.index[-1].date())
    feature_sets = {
        "vix_only": ["log_iv"],
        "vix_plus_trailing": ["log_iv", "log_rv22"],
        "vix_har": ["log_iv", "log_rv5", "log_rv22", "log_rv66"],
        "full": [
            "log_iv",
            "log_rv5",
            "log_rv22",
            "log_rv66",
            "negative_return_5d",
            "log_vix_change_5d",
        ],
    }
    alphas = [0.0, 1.0, 10.0, 100.0]
    selection_rows: list[dict[str, Any]] = []
    prediction_cache: dict[tuple[str, float, bool], pd.Series] = {}
    for feature_name, columns in feature_sets.items():
        for alpha in alphas:
            for smearing in [False, True]:
                prediction, _ = quarterly_expanding_predictions(frame, columns, alpha, smearing)
                key = (feature_name, alpha, smearing)
                prediction_cache[key] = prediction
                metrics = forecast_metrics(frame, prediction, validation_start, validation_end)
                selection_rows.append(
                    {
                        "feature_set": feature_name,
                        "alpha": alpha,
                        "smearing": smearing,
                        **{f"validation_{name}": value for name, value in metrics.items()},
                    }
                )
    selection = pd.DataFrame(selection_rows).sort_values(
        ["validation_qlike", "validation_log_rmse", "feature_set", "alpha"], ignore_index=True
    )
    winner = selection.iloc[0]
    winner_key = (str(winner.feature_set), float(winner.alpha), bool(winner.smearing))
    point, model_audit = quarterly_expanding_predictions(
        frame, feature_sets[winner_key[0]], winner_key[1], winner_key[2]
    )
    frame["point_forecast"] = point
    upper, calibration_audit = rolling_upper_bound(frame, point)
    frame["upper_predictive_bound"] = upper

    forecast_test = {
        "selected_model": forecast_metrics(frame, point, test_start, test_end),
        "raw_vix_variance": forecast_metrics(frame, frame["implied_variance"], test_start, test_end),
        "trailing_22d_variance": forecast_metrics(frame, frame["trailing_variance_22d"], test_start, test_end),
    }
    forecast_validation = {
        "selected_model": forecast_metrics(frame, point, validation_start, validation_end),
        "raw_vix_variance": forecast_metrics(frame, frame["implied_variance"], validation_start, validation_end),
        "trailing_22d_variance": forecast_metrics(
            frame, frame["trailing_variance_22d"], validation_start, validation_end
        ),
    }

    dm_sample = pd.DataFrame(
        {
            "actual": frame["future_variance"],
            "model": point,
            "vix": frame["implied_variance"],
        }
    ).loc[test_start:test_end].dropna()
    qlike_difference = qlike_loss(dm_sample["actual"], dm_sample["model"]) - qlike_loss(
        dm_sample["actual"], dm_sample["vix"]
    )
    model_log_error = np.log(dm_sample["actual"]) - np.log(dm_sample["model"])
    vix_log_error = np.log(dm_sample["actual"]) - np.log(dm_sample["vix"])
    forecast_inference = {
        "qlike_selected_minus_vix": newey_west_mean_test(qlike_difference, lags=HORIZON - 1),
        "squared_log_error_selected_minus_vix": newey_west_mean_test(
            model_log_error.to_numpy() ** 2 - vix_log_error.to_numpy() ** 2,
            lags=HORIZON - 1,
        ),
    }

    target_volatility = 0.12
    leverage = {
        "buy_and_hold": pd.Series(1.0, index=frame.index),
        "trailing_risk_target": (target_volatility / np.sqrt(frame["trailing_variance_22d"])).clip(0.2, 1.5),
        "vix_target": (target_volatility / np.sqrt(frame["implied_variance"])).clip(0.2, 1.5),
        "point_forecast_target": (target_volatility / np.sqrt(point)).clip(0.2, 1.5),
        "uncertainty_bound": (target_volatility / np.sqrt(upper)).clip(0.2, 1.5),
    }
    common_validation = leverage["uncertainty_bound"].loc[validation_start:validation_end].dropna()
    fixed_validation_exposure = float(common_validation.mean())
    leverage["fixed_validation_exposure"] = pd.Series(fixed_validation_exposure, index=frame.index)
    simulations = {
        name: simulate_exposure_strategy(exposure, frame["next_simple_return"], cost_bps=1.0)
        for name, exposure in leverage.items()
    }
    common_test_index = simulations["uncertainty_bound"].returns.loc[test_start:test_end].index
    common_validation_index = simulations["uncertainty_bound"].returns.loc[
        validation_start:validation_end
    ].index

    def common_metrics(sim: StrategySimulation, index: pd.DatetimeIndex) -> dict[str, float | int | str]:
        return performance_metrics(
            sim.returns.reindex(index),
            turnover=sim.turnover.reindex(index),
            exposure=sim.exposure.reindex(index),
        )

    strategy_test = {name: common_metrics(sim, common_test_index) for name, sim in simulations.items()}
    strategy_validation = {
        name: common_metrics(sim, common_validation_index) for name, sim in simulations.items()
    }

    cost_rows = []
    for cost_bps in [0.0, 1.0, 5.0, 10.0]:
        sim = simulate_exposure_strategy(leverage["uncertainty_bound"], frame["next_simple_return"], cost_bps)
        cost_rows.append({"cost_bps_per_exposure_change": cost_bps, **common_metrics(sim, common_test_index)})
    cost_sensitivity = pd.DataFrame(cost_rows)

    subperiod_rows: list[dict[str, Any]] = []
    for period_name, start, end in [
        ("pre_covid", "2013-01-01", "2019-12-31"),
        ("covid_and_after", "2020-01-01", test_end),
    ]:
        period_index = common_test_index[(common_test_index >= start) & (common_test_index <= end)]
        for name, sim in simulations.items():
            subperiod_rows.append({"period": period_name, "strategy": name, **common_metrics(sim, period_index)})
    subperiod = pd.DataFrame(subperiod_rows)

    coverage = {
        "validation": _coverage(frame, upper, validation_start, validation_end),
        "locked_test": _coverage(frame, upper, test_start, test_end),
    }
    validation_vix = frame.loc[validation_start:validation_end, "vix"].dropna()
    cutpoints = validation_vix.quantile([0.2, 0.4, 0.6, 0.8]).to_numpy()
    test_coverage_frame = pd.DataFrame(
        {
            "actual": frame["future_variance"],
            "upper": upper,
            "point": point,
            "vix": frame["vix"],
        }
    ).loc[test_start:test_end].dropna()
    test_coverage_frame["validation_vix_regime"] = pd.cut(
        test_coverage_frame["vix"],
        bins=np.r_[-np.inf, cutpoints, np.inf],
        labels=["Q1_low", "Q2", "Q3", "Q4", "Q5_high"],
    )
    coverage_regime_rows = []
    for regime, sample in test_coverage_frame.groupby("validation_vix_regime", observed=True):
        coverage_regime_rows.append(
            {
                "validation_vix_regime": str(regime),
                "n_forecasts": len(sample),
                "vix_min": float(sample["vix"].min()),
                "vix_max": float(sample["vix"].max()),
                "empirical_upper_coverage": float((sample["actual"] <= sample["upper"]).mean()),
                "mean_upper_to_point_ratio": float((sample["upper"] / sample["point"]).mean()),
            }
        )
    coverage_by_vix_regime = pd.DataFrame(coverage_regime_rows)
    bootstrap = paired_moving_block_bootstrap(
        simulations["uncertainty_bound"].returns.reindex(common_test_index),
        simulations["fixed_validation_exposure"].returns.reindex(common_test_index),
    )

    selection.to_csv(output_dir / "selection_grid.csv", index=False)
    pd.DataFrame(forecast_test).T.to_csv(output_dir / "test_forecast_metrics.csv")
    pd.DataFrame(forecast_validation).T.to_csv(output_dir / "validation_forecast_metrics.csv")
    pd.DataFrame(strategy_test).T.to_csv(output_dir / "test_strategy_metrics.csv")
    pd.DataFrame(strategy_validation).T.to_csv(output_dir / "validation_strategy_metrics.csv")
    cost_sensitivity.to_csv(output_dir / "cost_sensitivity.csv", index=False)
    subperiod.to_csv(output_dir / "subperiod_metrics.csv", index=False)
    coverage_by_vix_regime.to_csv(output_dir / "test_coverage_by_validation_vix_regime.csv", index=False)
    model_audit.to_csv(output_dir / "model_refit_audit.csv", index=False)
    calibration_audit.to_csv(output_dir / "calibration_maturity_audit.csv", index=False)
    frame[
        [
            "future_variance",
            "target_end",
            "implied_variance",
            "trailing_variance_22d",
            "point_forecast",
            "upper_predictive_bound",
            "next_simple_return",
        ]
    ].to_csv(output_dir / "forecast_panel.csv", index_label="date")
    strategy_daily = pd.DataFrame(index=common_test_index)
    for name, sim in simulations.items():
        strategy_daily[f"{name}_return"] = sim.returns
        strategy_daily[f"{name}_exposure"] = sim.exposure
        strategy_daily[f"{name}_turnover"] = sim.turnover
    strategy_daily.to_csv(output_dir / "test_strategy_daily.csv", index_label="forecast_date")
    _make_plots(output_dir, frame, simulations)

    robust_test = strategy_test["uncertainty_bound"]
    buy_hold_test = strategy_test["buy_and_hold"]
    vix_test = strategy_test["vix_target"]
    headline = {
        "max_drawdown_reduction_vs_buy_hold_relative": float(
            1.0 - abs(robust_test["max_drawdown"]) / abs(buy_hold_test["max_drawdown"])
        ),
        "max_drawdown_improvement_vs_buy_hold_points": float(
            robust_test["max_drawdown"] - buy_hold_test["max_drawdown"]
        ),
        "max_drawdown_improvement_vs_vix_target_points": float(
            robust_test["max_drawdown"] - vix_test["max_drawdown"]
        ),
        "log_rmse_improvement_vs_raw_vix": float(
            1.0 - forecast_test["selected_model"]["log_rmse"] / forecast_test["raw_vix_variance"]["log_rmse"]
        ),
        "qlike_change_vs_raw_vix": float(
            forecast_test["selected_model"]["qlike"] - forecast_test["raw_vix_variance"]["qlike"]
        ),
    }
    results = {
        "project": "Uncertainty-Calibrated SPX Volatility Control",
        "data": {
            "spx_source_file": spx_json.name,
            "vix_source_file": vix_csv.name,
            "start": str(market.index[0].date()),
            "end": str(market.index[-1].date()),
            "n_aligned_market_days": int(len(market)),
        },
        "protocol": {
            "forecast_horizon_trading_days": HORIZON,
            "validation_period": [validation_start, validation_end],
            "locked_test_period": [test_start, test_end],
            "selection_objective": "minimum validation QLIKE",
            "quarterly_refit": "expanding; only labels whose 22-day target ended before refit date",
            "upper_bound": "rolling 90th percentile of the most recent 756 matured OOS log residuals",
            "target_volatility": target_volatility,
            "exposure_clip": [0.2, 1.5],
            "transaction_cost": "1 bp times absolute change in SPX exposure",
            "cash_return": 0.0,
        },
        "selected_configuration": {
            "feature_set": winner_key[0],
            "features": feature_sets[winner_key[0]],
            "ridge_alpha": winner_key[1],
            "duan_smearing": winner_key[2],
            "fixed_validation_exposure_benchmark": fixed_validation_exposure,
        },
        "validation_forecast_metrics": forecast_validation,
        "locked_test_forecast_metrics": forecast_test,
        "forecast_loss_inference": forecast_inference,
        "upper_bound_coverage": coverage,
        "upper_bound_coverage_by_validation_vix_regime": coverage_regime_rows,
        "validation_strategy_metrics": strategy_validation,
        "locked_test_strategy_metrics": strategy_test,
        "locked_test_headline": headline,
        "bootstrap_vs_fixed_validation_exposure": bootstrap,
        "limitations": [
            "SPX is a price index: dividends are omitted, and the implementation assumes a scalable SPX-like instrument.",
            "Daily close-to-close squared returns are a noisy realized-variance proxy; no intraday data are used.",
            "The residual-quantile bound is conformal-style calibration, not a finite-sample coverage guarantee under serial dependence.",
            "VIX itself is not traded; it is used only as an information variable and risk-sizing benchmark.",
            "Cash earns zero; financing, taxes, margin, and market impact are omitted.",
            "The selected model improves log-RMSE but is reported even if raw VIX wins on locked-test QLIKE.",
        ],
    }
    write_json(output_dir / "results.json", results)
    return results
