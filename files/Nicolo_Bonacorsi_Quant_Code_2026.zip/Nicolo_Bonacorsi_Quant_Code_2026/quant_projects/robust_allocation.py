from __future__ import annotations

import io
import math
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .common import (
    TRADING_DAYS,
    drawdown_series,
    paired_moving_block_bootstrap,
    performance_metrics,
    write_json,
)


@dataclass
class PortfolioSimulation:
    net_returns: pd.Series
    gross_returns: pd.Series
    l1_turnover: pd.Series
    target_weights: pd.DataFrame


def _read_ff_section(path: Path, marker: str) -> pd.DataFrame:
    rows: list[str] = []
    header: str | None = None
    marker_seen = False
    date_line = re.compile(r"^\s*\d{8},")
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != 1:
            raise ValueError(f"Expected one CSV in {path}, found {len(names)}")
        with archive.open(names[0]) as handle:
            for raw in handle:
                line = raw.decode("latin1")
                if not marker_seen:
                    marker_seen = marker in line
                    continue
                if header is None:
                    if line.lstrip().startswith(","):
                        header = "date" + line
                    continue
                if date_line.match(line):
                    rows.append(line)
                elif rows:
                    break
    if header is None or not rows:
        raise ValueError(f"Could not locate section: {marker}")
    frame = pd.read_csv(io.StringIO(header + "".join(rows)))
    frame["date"] = pd.to_datetime(frame["date"].astype(str), format="%Y%m%d")
    return frame.set_index("date").apply(pd.to_numeric, errors="coerce")


def load_ff25_aggregated_daily(path: Path) -> pd.DataFrame:
    """Aggregate the 100 FF size–value cells into a continuously populated 5×5 panel.

    Some extreme 10×10 cells are empty for full portfolio-formation years.  Silently
    dropping those dates creates artificial gaps.  We instead aggregate adjacent 2×2
    cells with lagged total market capitalization (firm count × average firm size),
    assigning zero weight to an empty cell.  The construction rule is fixed for the
    whole sample and does not inspect future returns.
    """
    returns_100 = _read_ff_section(path, "Average Value Weighted Returns -- Daily")
    returns_100 = returns_100.replace([-99.99, -999.0], np.nan) / 100.0
    firm_count = _read_ff_section(path, "Number of Firms in Portfolios").replace(
        [-99.99, -999.0], np.nan
    )
    average_size = _read_ff_section(path, "Average Firm Size").replace([-99.99, -999.0], np.nan)
    if not returns_100.index.equals(firm_count.index) or not returns_100.index.equals(average_size.index):
        raise AssertionError("Return, firm-count, and firm-size sections must share the same dates.")
    market_cap = firm_count * average_size
    market_cap = market_cap.where(firm_count > 0.0, 0.0)
    lagged_market_cap = market_cap.shift(1)

    aggregated: dict[str, pd.Series] = {}
    for size_group in range(5):
        for value_group in range(5):
            columns = [
                returns_100.columns[10 * size_decile + value_decile]
                for size_decile in (2 * size_group, 2 * size_group + 1)
                for value_decile in (2 * value_group, 2 * value_group + 1)
            ]
            available = returns_100[columns].notna()
            weights = lagged_market_cap[columns].where(available, 0.0).fillna(0.0)
            numerator = (returns_100[columns].fillna(0.0) * weights).sum(axis=1)
            denominator = weights.sum(axis=1)
            group_return = numerator / denominator
            aggregated[f"ME{size_group + 1}_BM{value_group + 1}"] = group_return

    modern = pd.DataFrame(aggregated).loc["1963-07-01":]
    if modern.shape[1] != 25 or modern.isna().any().any():
        raise AssertionError("The aggregated 5×5 panel must be complete and have 25 columns.")
    maximum_gap = modern.index.to_series().diff().max()
    if maximum_gap > pd.Timedelta(days=7):
        raise AssertionError(f"Unexpected calendar gap in the FF panel: {maximum_gap}")
    return modern


def project_capped_simplex(values: np.ndarray, cap: float) -> np.ndarray:
    """Euclidean projection onto {w >= 0, sum(w)=1, w_i <= cap}."""
    v = np.asarray(values, dtype=float)
    n = len(v)
    if cap * n < 1.0 - 1e-12:
        raise ValueError("The cap is too small for a unit-sum portfolio.")
    low = float(np.min(v - cap))
    high = float(np.max(v))
    for _ in range(80):
        level = 0.5 * (low + high)
        w = np.clip(v - level, 0.0, cap)
        if w.sum() > 1.0:
            low = level
        else:
            high = level
    w = np.clip(v - 0.5 * (low + high), 0.0, cap)
    w /= w.sum()
    return w


def first_trading_day_positions(index: pd.DatetimeIndex, earliest: str) -> np.ndarray:
    month = index.to_period("M")
    positions = np.flatnonzero(np.r_[True, month[1:].values != month[:-1].values])
    return positions[index[positions] >= pd.Timestamp(earliest)]


def precompute_covariances(
    returns: pd.DataFrame,
    lookback: int,
    earliest_rebalance: str = "1998-01-01",
) -> list[tuple[int, np.ndarray, float]]:
    array = returns.to_numpy()
    positions = first_trading_day_positions(returns.index, earliest_rebalance)
    positions = positions[positions >= lookback]
    cache: list[tuple[int, np.ndarray, float]] = []
    for pos in positions:
        covariance = np.cov(array[pos - lookback : pos], rowvar=False)
        average_variance = float(np.trace(covariance) / covariance.shape[0])
        cache.append((int(pos), covariance, average_variance))
    return cache


def ridge_targets_from_cache(
    cache: list[tuple[int, np.ndarray, float]],
    n_assets: int,
    ridge: float,
    cap: float | None,
) -> dict[int, np.ndarray]:
    ones = np.ones(n_assets)
    identity = np.eye(n_assets)
    targets: dict[int, np.ndarray] = {}
    for pos, covariance, average_variance in cache:
        regularized = covariance + ridge * average_variance * identity
        raw = np.linalg.solve(regularized, ones)
        raw /= raw.sum()
        targets[pos] = raw if cap is None else project_capped_simplex(raw, cap)
    return targets


def equal_weight_targets(returns: pd.DataFrame, earliest: str = "1998-01-01") -> dict[int, np.ndarray]:
    positions = first_trading_day_positions(returns.index, earliest)
    weight = np.ones(returns.shape[1]) / returns.shape[1]
    return {int(pos): weight.copy() for pos in positions}


def inverse_volatility_targets(
    returns: pd.DataFrame,
    lookback: int = 252,
    earliest: str = "1998-01-01",
) -> dict[int, np.ndarray]:
    positions = first_trading_day_positions(returns.index, earliest)
    positions = positions[positions >= lookback]
    array = returns.to_numpy()
    targets: dict[int, np.ndarray] = {}
    for pos in positions:
        inverse_vol = 1.0 / array[pos - lookback : pos].std(axis=0, ddof=1)
        targets[int(pos)] = inverse_vol / inverse_vol.sum()
    return targets


def simulate_monthly_portfolio(
    returns: pd.DataFrame,
    targets: dict[int, np.ndarray],
    cost_rate: float,
) -> PortfolioSimulation:
    """Apply target weights before each rebalance-day return and drift between rebalances."""
    array = returns.to_numpy()
    n_days, n_assets = array.shape
    gross = np.full(n_days, np.nan)
    net = np.full(n_days, np.nan)
    turnover = np.zeros(n_days)
    current: np.ndarray | None = None
    target_rows: list[np.ndarray] = []
    target_dates: list[pd.Timestamp] = []

    for day in range(n_days):
        if day in targets:
            target = targets[day].copy()
            if current is not None:
                turnover[day] = float(np.abs(target - current).sum())
            current = target
            target_rows.append(target)
            target_dates.append(returns.index[day])
        if current is None:
            continue
        gross[day] = float(current @ array[day])
        net[day] = gross[day] - cost_rate * turnover[day]
        denominator = 1.0 + gross[day]
        current = current * (1.0 + array[day]) / denominator

    target_frame = pd.DataFrame(target_rows, index=pd.DatetimeIndex(target_dates), columns=returns.columns)
    return PortfolioSimulation(
        net_returns=pd.Series(net, index=returns.index, name="net_return"),
        gross_returns=pd.Series(gross, index=returns.index, name="gross_return"),
        l1_turnover=pd.Series(turnover, index=returns.index, name="l1_turnover"),
        target_weights=target_frame,
    )


def _metrics_for_period(simulation: PortfolioSimulation, start: str, end: str) -> dict[str, float | int | str]:
    return performance_metrics(
        simulation.net_returns.loc[start:end],
        turnover=simulation.l1_turnover.loc[start:end],
    )


def _make_plots(
    output_dir: Path,
    selected: PortfolioSimulation,
    equal_weight: PortfolioSimulation,
    inverse_vol: PortfolioSimulation,
    selection: pd.DataFrame,
    selected_lookback: int,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    test = slice("2013-01-01", None)
    series = {
        "Uncertainty-regularized": selected.net_returns.loc[test].dropna(),
        "Equal weight": equal_weight.net_returns.loc[test].dropna(),
        "Inverse volatility": inverse_vol.net_returns.loc[test].dropna(),
    }

    fig, axes = plt.subplots(2, 1, figsize=(10.5, 7.0), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
    for label, ret in series.items():
        axes[0].plot((1.0 + ret).cumprod(), label=label, linewidth=1.5)
        axes[1].plot(drawdown_series(ret), label=label, linewidth=1.2)
    axes[0].set_ylabel("Growth of $1")
    axes[0].set_title("Locked test: 25 U.S. size–value portfolios (2013–2026)")
    axes[0].legend(ncol=3, frameon=False)
    axes[0].grid(alpha=0.2)
    axes[1].set_ylabel("Drawdown")
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "test_wealth_and_drawdown.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10.5, 4.6))
    for label, ret in series.items():
        rolling = ret.rolling(63).std() * math.sqrt(TRADING_DAYS)
        ax.plot(rolling, label=label, linewidth=1.2)
    ax.set_title("63-day realized volatility on the locked test")
    ax.set_ylabel("Annualized volatility")
    ax.legend(ncol=3, frameon=False)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "test_rolling_volatility.png", dpi=180)
    plt.close(fig)

    subset = selection[selection["lookback_days"] == selected_lookback]
    pivot = subset.pivot(index="ridge", columns="weight_cap", values="validation_volatility")
    fig, ax = plt.subplots(figsize=(7.8, 4.8))
    image = ax.imshow(pivot.to_numpy(), aspect="auto", cmap="viridis_r")
    ax.set_xticks(range(len(pivot.columns)), [f"{x:.3g}" for x in pivot.columns])
    ax.set_yticks(range(len(pivot.index)), [f"{x:.3g}" for x in pivot.index])
    ax.set_xlabel("Maximum asset weight")
    ax.set_ylabel("Ridge multiplier")
    ax.set_title(f"Validation volatility; lookback = {selected_lookback} days")
    fig.colorbar(image, ax=ax, label="Annualized volatility")
    fig.tight_layout()
    fig.savefig(output_dir / "validation_hyperparameter_surface.png", dpi=180)
    plt.close(fig)

    average_weight = selected.target_weights.loc["2013":].mean().to_numpy().reshape(5, 5)
    fig, ax = plt.subplots(figsize=(7.6, 6.0))
    image = ax.imshow(average_weight, origin="lower", cmap="magma")
    ax.set_xticks(range(5), range(1, 6))
    ax.set_yticks(range(5), range(1, 6))
    ax.set_xlabel("Book-to-market quintile (low → high)")
    ax.set_ylabel("Size quintile (small → big)")
    ax.set_title("Average locked-test allocation across the 5×5 characteristic lattice")
    fig.colorbar(image, ax=ax, label="Portfolio weight")
    fig.tight_layout()
    fig.savefig(output_dir / "test_average_weight_lattice.png", dpi=180)
    plt.close(fig)


def run(data_path: Path, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    returns = load_ff25_aggregated_daily(data_path)
    cost_rate = 10.0 / 10_000.0
    lookbacks = [252, 504, 756, 1260]
    ridges = [0.0, 0.05, 0.10, 0.25, 0.50, 1.0, 2.0]
    caps = [0.05, 0.075, 0.10, 0.15, 0.20]
    validation_start, validation_end = "2000-01-01", "2012-12-31"
    test_start, test_end = "2013-01-01", str(returns.index[-1].date())

    selection_rows: list[dict] = []
    target_cache: dict[tuple[int, float, float], dict[int, np.ndarray]] = {}
    covariance_caches = {lookback: precompute_covariances(returns, lookback) for lookback in lookbacks}
    for lookback in lookbacks:
        cache = covariance_caches[lookback]
        for ridge in ridges:
            raw_targets = ridge_targets_from_cache(cache, returns.shape[1], ridge, cap=None)
            for cap in caps:
                targets = {pos: project_capped_simplex(weight, cap) for pos, weight in raw_targets.items()}
                target_cache[(lookback, ridge, cap)] = targets
                simulation = simulate_monthly_portfolio(returns, targets, cost_rate)
                metrics = _metrics_for_period(simulation, validation_start, validation_end)
                selection_rows.append(
                    {
                        "lookback_days": lookback,
                        "ridge": ridge,
                        "weight_cap": cap,
                        "validation_volatility": metrics["annualized_volatility"],
                        "validation_sharpe": metrics["sharpe_zero_cash"],
                        "validation_cagr": metrics["cagr"],
                        "validation_max_drawdown": metrics["max_drawdown"],
                        "validation_l1_turnover": metrics["annualized_l1_turnover"],
                    }
                )

    selection = pd.DataFrame(selection_rows).sort_values(
        ["validation_volatility", "validation_l1_turnover", "lookback_days"],
        ignore_index=True,
    )
    winner = selection.iloc[0]
    selected_key = (int(winner.lookback_days), float(winner.ridge), float(winner.weight_cap))
    selected_targets = target_cache[selected_key]
    selected = simulate_monthly_portfolio(returns, selected_targets, cost_rate)
    equal_weight = simulate_monthly_portfolio(returns, equal_weight_targets(returns), cost_rate)
    inverse_vol = simulate_monthly_portfolio(returns, inverse_volatility_targets(returns), cost_rate)
    unregularized_targets = target_cache[(selected_key[0], 0.0, selected_key[2])]
    unregularized = simulate_monthly_portfolio(returns, unregularized_targets, cost_rate)

    simulations = {
        "uncertainty_regularized": selected,
        "equal_weight": equal_weight,
        "inverse_volatility": inverse_vol,
        "unregularized_capped_gmv": unregularized,
    }
    test_metrics = {
        name: _metrics_for_period(sim, test_start, test_end) for name, sim in simulations.items()
    }
    validation_metrics = {
        name: _metrics_for_period(sim, validation_start, validation_end) for name, sim in simulations.items()
    }

    subperiod_rows: list[dict] = []
    for label, start, end in [
        ("pre_covid", "2013-01-01", "2019-12-31"),
        ("covid_and_after", "2020-01-01", test_end),
    ]:
        for name, sim in simulations.items():
            subperiod_rows.append({"period": label, "strategy": name, **_metrics_for_period(sim, start, end)})
    subperiod = pd.DataFrame(subperiod_rows)

    cost_rows: list[dict] = []
    for cost_bps in [0.0, 5.0, 10.0, 25.0, 50.0]:
        sim = simulate_monthly_portfolio(returns, selected_targets, cost_bps / 10_000.0)
        cost_rows.append({"cost_bps_per_dollar_traded": cost_bps, **_metrics_for_period(sim, test_start, test_end)})
    cost_sensitivity = pd.DataFrame(cost_rows)

    bootstrap = paired_moving_block_bootstrap(
        selected.net_returns.loc[test_start:test_end],
        equal_weight.net_returns.loc[test_start:test_end],
    )
    bootstrap_sensitivity_rows = []
    for block_length in [5, 21, 63, 126]:
        sensitivity = (
            bootstrap
            if block_length == 21
            else paired_moving_block_bootstrap(
                selected.net_returns.loc[test_start:test_end],
                equal_weight.net_returns.loc[test_start:test_end],
                block_length=block_length,
                replications=2500,
            )
        )
        vol_result = sensitivity["relative_volatility_reduction"]
        sharpe_result = sensitivity["annualized_sharpe_difference"]
        bootstrap_sensitivity_rows.append(
            {
                "block_length_days": block_length,
                "replications": sensitivity["replications"],
                "volatility_reduction_mean": vol_result["bootstrap_mean"],
                "volatility_reduction_ci_95_low": vol_result["ci_95_low"],
                "volatility_reduction_ci_95_high": vol_result["ci_95_high"],
                "volatility_reduction_p_nonpositive": vol_result["p_nonpositive_add_one"],
                "sharpe_difference_mean": sharpe_result["bootstrap_mean"],
                "sharpe_difference_ci_95_low": sharpe_result["ci_95_low"],
                "sharpe_difference_ci_95_high": sharpe_result["ci_95_high"],
            }
        )
    bootstrap_sensitivity = pd.DataFrame(bootstrap_sensitivity_rows)

    target_test = selected.target_weights.loc[test_start:test_end]
    diagnostics = {
        "average_effective_number_of_assets": float((1.0 / target_test.pow(2).sum(axis=1)).mean()),
        "maximum_target_weight_observed": float(target_test.max().max()),
        "minimum_target_weight_observed": float(target_test.min().min()),
        "number_of_test_rebalances": int(len(target_test)),
    }

    test_daily = pd.DataFrame(index=returns.loc[test_start:test_end].index)
    for name, sim in simulations.items():
        test_daily[f"{name}_net_return"] = sim.net_returns
        test_daily[f"{name}_l1_turnover"] = sim.l1_turnover
    selection.to_csv(output_dir / "selection_grid.csv", index=False)
    pd.DataFrame(test_metrics).T.to_csv(output_dir / "test_metrics.csv")
    pd.DataFrame(validation_metrics).T.to_csv(output_dir / "validation_metrics.csv")
    subperiod.to_csv(output_dir / "subperiod_metrics.csv", index=False)
    cost_sensitivity.to_csv(output_dir / "cost_sensitivity.csv", index=False)
    bootstrap_sensitivity.to_csv(output_dir / "bootstrap_block_sensitivity.csv", index=False)
    test_daily.to_csv(output_dir / "test_daily_returns.csv", index_label="date")
    selected.target_weights.to_csv(output_dir / "selected_target_weights.csv", index_label="rebalance_date")

    audit_rows = []
    for position in sorted(selected_targets):
        audit_rows.append(
            {
                "rebalance_date": returns.index[position],
                "training_start": returns.index[position - selected_key[0]],
                "training_end": returns.index[position - 1],
                "lookback_days": selected_key[0],
                "strictly_past_training": bool(returns.index[position - 1] < returns.index[position]),
            }
        )
    pd.DataFrame(audit_rows).to_csv(output_dir / "training_window_audit.csv", index=False)
    _make_plots(output_dir, selected, equal_weight, inverse_vol, selection, selected_key[0])

    selected_test = test_metrics["uncertainty_regularized"]
    equal_test = test_metrics["equal_weight"]
    headline = {
        "relative_volatility_reduction_vs_equal_weight": float(
            1.0 - selected_test["annualized_volatility"] / equal_test["annualized_volatility"]
        ),
        "sharpe_change_vs_equal_weight": float(
            selected_test["sharpe_zero_cash"] - equal_test["sharpe_zero_cash"]
        ),
        "cagr_difference_vs_equal_weight": float(selected_test["cagr"] - equal_test["cagr"]),
        "max_drawdown_improvement_points": float(
            selected_test["max_drawdown"] - equal_test["max_drawdown"]
        ),
    }
    results = {
        "project": "Uncertainty-Regularized Allocation Across 25 U.S. Equity Characteristic Portfolios",
        "data": {
            "source_file": data_path.name,
            "start": str(returns.index[0].date()),
            "end": str(returns.index[-1].date()),
            "n_daily_observations": int(len(returns)),
            "n_portfolios": int(returns.shape[1]),
        },
        "protocol": {
            "validation_period": [validation_start, validation_end],
            "locked_test_period": [test_start, test_end],
            "selection_objective": "minimum validation annualized volatility; turnover and lookback break ties",
            "candidate_lookbacks_days": lookbacks,
            "candidate_ridge_multipliers": ridges,
            "candidate_weight_caps": caps,
            "rebalance": "first trading day of each month using returns ending the prior trading day",
            "transaction_cost": "10 bps times full L1 change in portfolio weights",
        },
        "selected_configuration": {
            "lookback_days": selected_key[0],
            "ridge_multiplier": selected_key[1],
            "maximum_weight": selected_key[2],
        },
        "validation_metrics": validation_metrics,
        "locked_test_metrics": test_metrics,
        "locked_test_headline": headline,
        "weight_diagnostics": diagnostics,
        "bootstrap_inference": bootstrap,
        "bootstrap_block_length_sensitivity": bootstrap_sensitivity_rows,
        "limitations": [
            "The 100 characteristic portfolios are research portfolios, not directly traded securities.",
            "The backtest uses published portfolio returns and cannot model constituent-level capacity or market impact.",
            "Cash earns zero and taxes, borrow constraints, and management fees are omitted.",
            "Hyperparameters are selected once on 2000–2012; the 2013–2026 test is untouched by selection.",
        ],
    }
    write_json(output_dir / "results.json", results)
    return results
