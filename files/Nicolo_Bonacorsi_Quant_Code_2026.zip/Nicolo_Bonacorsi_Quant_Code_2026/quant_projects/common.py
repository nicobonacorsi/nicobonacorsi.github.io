from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import norm

TRADING_DAYS = 252


def json_ready(value: Any) -> Any:
    """Convert common NumPy/pandas objects into strict JSON values."""
    if isinstance(value, dict):
        return {str(k): json_ready(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(v) for v in value]
    if isinstance(value, (int, np.integer)) and not isinstance(value, bool):
        return int(value)
    if isinstance(value, (float, np.floating)):
        numeric = float(value)
        return None if not math.isfinite(numeric) else numeric
    if isinstance(value, (pd.Timestamp,)):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    return value


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(json_ready(payload), indent=2, sort_keys=True) + "\n")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def drawdown_series(returns: pd.Series) -> pd.Series:
    wealth = (1.0 + returns.fillna(0.0)).cumprod()
    return wealth / wealth.cummax() - 1.0


def performance_metrics(
    returns: pd.Series,
    turnover: pd.Series | None = None,
    exposure: pd.Series | None = None,
) -> dict[str, float | int | str]:
    r = returns.dropna().astype(float)
    if len(r) < 2:
        raise ValueError("At least two returns are required.")
    wealth = (1.0 + r).cumprod()
    years = len(r) / TRADING_DAYS
    cagr = float(wealth.iloc[-1] ** (1.0 / years) - 1.0)
    vol = float(r.std(ddof=1) * math.sqrt(TRADING_DAYS))
    ann_mean = float(r.mean() * TRADING_DAYS)
    downside = r[r < 0.0]
    sortino = float(r.mean() / downside.std(ddof=1) * math.sqrt(TRADING_DAYS))
    max_dd = float((wealth / wealth.cummax() - 1.0).min())
    cutoff = max(1, int(math.ceil(0.05 * len(r))))
    es_5 = float(np.sort(r.to_numpy())[:cutoff].mean())
    out: dict[str, float | int | str] = {
        "start": str(r.index[0].date()),
        "end": str(r.index[-1].date()),
        "n_days": int(len(r)),
        "cagr": cagr,
        "annualized_mean": ann_mean,
        "annualized_volatility": vol,
        "sharpe_zero_cash": float(ann_mean / vol),
        "sortino_zero_cash": sortino,
        "max_drawdown": max_dd,
        "calmar": float(cagr / abs(max_dd)) if max_dd < 0 else float("nan"),
        "worst_day": float(r.min()),
        "daily_expected_shortfall_5pct": es_5,
    }
    if turnover is not None:
        t = turnover.reindex(r.index).fillna(0.0)
        out["annualized_l1_turnover"] = float(t.mean() * TRADING_DAYS)
    if exposure is not None:
        e = exposure.reindex(r.index)
        out["average_exposure"] = float(e.mean())
        out["maximum_exposure"] = float(e.max())
    return out


def newey_west_mean_test(values: np.ndarray, lags: int) -> dict[str, float]:
    """Two-sided HAC test of E[values] = 0 using Bartlett weights."""
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    mean = float(x.mean())
    centered = x - mean
    long_run_var = float(centered @ centered / n)
    for lag in range(1, min(lags, n - 1) + 1):
        gamma = float(centered[lag:] @ centered[:-lag] / n)
        long_run_var += 2.0 * (1.0 - lag / (lags + 1.0)) * gamma
    se = math.sqrt(max(long_run_var, 0.0) / n)
    statistic = mean / se if se > 0 else float("nan")
    p_value = float(2.0 * norm.sf(abs(statistic))) if np.isfinite(statistic) else float("nan")
    return {"mean_difference": mean, "hac_statistic": statistic, "p_value_two_sided": p_value}


def paired_moving_block_bootstrap(
    candidate: pd.Series,
    benchmark: pd.Series,
    block_length: int = 21,
    replications: int = 5000,
    seed: int = 20260716,
) -> dict[str, Any]:
    """Paired circular moving-block bootstrap for volatility and Sharpe deltas."""
    pair = pd.concat([candidate.rename("candidate"), benchmark.rename("benchmark")], axis=1).dropna()
    a = pair["candidate"].to_numpy()
    b = pair["benchmark"].to_numpy()
    n = len(pair)
    rng = np.random.default_rng(seed)
    n_blocks = int(math.ceil(n / block_length))
    vol_reduction = np.empty(replications)
    sharpe_delta = np.empty(replications)
    offsets = np.arange(block_length)
    for j in range(replications):
        starts = rng.integers(0, n, size=n_blocks)
        indices = ((starts[:, None] + offsets[None, :]) % n).ravel()[:n]
        aa, bb = a[indices], b[indices]
        sa, sb = aa.std(ddof=1), bb.std(ddof=1)
        vol_reduction[j] = 1.0 - sa / sb
        sharpe_delta[j] = math.sqrt(TRADING_DAYS) * (aa.mean() / sa - bb.mean() / sb)

    def summary(samples: np.ndarray) -> dict[str, float]:
        return {
            "bootstrap_mean": float(samples.mean()),
            "ci_95_low": float(np.quantile(samples, 0.025)),
            "ci_95_high": float(np.quantile(samples, 0.975)),
            "p_nonpositive_add_one": float((1 + np.sum(samples <= 0.0)) / (replications + 1)),
        }

    return {
        "method": "paired circular moving-block bootstrap",
        "block_length_days": block_length,
        "replications": replications,
        "seed": seed,
        "n_paired_days": n,
        "relative_volatility_reduction": summary(vol_reduction),
        "annualized_sharpe_difference": summary(sharpe_delta),
    }
