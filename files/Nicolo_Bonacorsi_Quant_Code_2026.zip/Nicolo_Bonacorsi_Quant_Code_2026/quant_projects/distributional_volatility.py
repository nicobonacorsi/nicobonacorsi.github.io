from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize

from .common import (
    TRADING_DAYS,
    drawdown_series,
    newey_west_mean_test,
    paired_moving_block_bootstrap,
    performance_metrics,
    write_json,
)
from .volatility_control import (
    HORIZON,
    build_forecast_frame,
    forecast_metrics,
    load_spx_vix,
    qlike_loss,
    quarterly_expanding_predictions,
)


@dataclass
class StrategySimulation:
    returns: pd.Series
    turnover: pd.Series
    exposure: pd.Series
    cash_return: pd.Series


def load_yahoo_adjusted_close(path: Path, expected_symbol: str) -> pd.Series:
    payload = json.loads(path.read_text())
    result = payload["chart"]["result"][0]
    if str(result["meta"].get("symbol")) != expected_symbol:
        raise AssertionError(f"Expected {expected_symbol}, found {result['meta'].get('symbol')}")
    dates = (
        pd.to_datetime(result["timestamp"], unit="s", utc=True)
        .tz_convert("America/New_York")
        .tz_localize(None)
        .normalize()
    )
    values = result["indicators"]["adjclose"][0]["adjclose"]
    series = pd.Series(values, index=dates, dtype=float, name=f"{expected_symbol}_adjusted_close")
    series.index.name = "date"
    if series.index.has_duplicates or not series.index.is_monotonic_increasing:
        raise AssertionError("Yahoo adjusted-close index must be unique and sorted.")
    return series.dropna()


def load_risk_free_daily(path: Path, index: pd.DatetimeIndex) -> pd.Series:
    frame = pd.read_csv(path)
    frame["observation_date"] = pd.to_datetime(frame["observation_date"])
    annual_percent = pd.to_numeric(frame["DGS3MO"], errors="coerce")
    annual = pd.Series(annual_percent.to_numpy(), index=frame["observation_date"], name="annual_yield")
    aligned = annual.reindex(index).ffill()
    daily = (1.0 + aligned / 100.0).pow(1.0 / TRADING_DAYS) - 1.0
    daily.name = "cash_return"
    return daily


def build_extended_frame(
    spx_json: Path,
    vix_csv: Path,
    spy_json: Path,
    risk_free_csv: Path,
) -> pd.DataFrame:
    market = load_spx_vix(spx_json, vix_csv)
    frame = build_forecast_frame(market)
    spx_log_return = np.log(market["adjclose"]).diff()
    frame["ewma_variance_094"] = (
        TRADING_DAYS * spx_log_return.pow(2).ewm(alpha=1.0 - 0.94, adjust=False).mean()
    ).reindex(frame.index)
    spy = load_yahoo_adjusted_close(spy_json, "SPY")
    spy_return = spy.pct_change()
    frame["next_spy_total_return"] = spy_return.shift(-1).reindex(frame.index)
    frame["cash_return"] = load_risk_free_daily(risk_free_csv, frame.index)
    frame["forecast_position"] = np.arange(len(frame), dtype=int)
    frame["interlaced_stream"] = frame["forecast_position"] % HORIZON
    return frame


def select_base_experts(
    frame: pd.DataFrame,
    development_start: str,
    development_end: str,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, dict[str, Any]]]:
    feature_sets = {
        "vix_only": ["log_iv"],
        "vix_har": ["log_iv", "log_rv5", "log_rv22", "log_rv66"],
        "full": [
            "log_iv",
            "log_rv5",
            "log_rv22",
            "log_rv66",
            "negative_return_5d",
            "log_vix_change_5d",
        ],
    }
    alphas = (0.0, 1.0, 10.0, 100.0)
    rows: list[dict[str, Any]] = []
    cache: dict[tuple[str, float, bool], pd.Series] = {}
    for feature_name, columns in feature_sets.items():
        for alpha in alphas:
            for smearing in (False, True):
                prediction, _ = quarterly_expanding_predictions(
                    frame,
                    columns,
                    alpha,
                    smearing,
                    prediction_start="2005-01-01",
                )
                cache[(feature_name, alpha, smearing)] = prediction
                metrics = forecast_metrics(frame, prediction, development_start, development_end)
                rows.append(
                    {
                        "feature_set": feature_name,
                        "alpha": alpha,
                        "smearing": smearing,
                        **{f"development_{name}": value for name, value in metrics.items()},
                    }
                )
    selection = pd.DataFrame(rows)
    expert_frame = pd.DataFrame(index=frame.index)
    chosen: dict[str, dict[str, Any]] = {}
    for feature_name in feature_sets:
        winner = (
            selection.loc[selection["feature_set"] == feature_name]
            .sort_values(["development_qlike", "development_log_rmse", "alpha"])
            .iloc[0]
        )
        key = (feature_name, float(winner.alpha), bool(winner.smearing))
        expert_frame[f"ridge_{feature_name}"] = cache[key]
        chosen[feature_name] = {
            "features": feature_sets[feature_name],
            "alpha": key[1],
            "duan_smearing": key[2],
        }
    expert_frame["raw_vix"] = frame["implied_variance"]
    expert_frame["trailing_22"] = frame["trailing_variance_22d"]
    expert_frame["ewma_094"] = frame["ewma_variance_094"]
    return selection, expert_frame, chosen


def fit_qlike_stacking_weights(
    actual: np.ndarray,
    forecasts: np.ndarray,
    penalty: float,
    combination: str,
    initial: np.ndarray | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    y = np.asarray(actual, dtype=float)
    f = np.asarray(forecasts, dtype=float)
    n_experts = f.shape[1]
    equal = np.ones(n_experts) / n_experts
    start = equal if initial is None else np.asarray(initial, dtype=float)
    log_f = np.log(f)

    def combined(weights: np.ndarray) -> np.ndarray:
        if combination == "arithmetic":
            return f @ weights
        if combination == "geometric":
            return np.exp(log_f @ weights)
        raise ValueError(f"Unknown stacking combination: {combination}")

    def objective(weights: np.ndarray) -> float:
        prediction = combined(weights)
        return float(
            qlike_loss(y, prediction).mean()
            + penalty * np.sum((weights - equal) ** 2)
        )

    def gradient(weights: np.ndarray) -> np.ndarray:
        prediction = combined(weights)
        if combination == "arithmetic":
            loss_gradient = f.T @ ((prediction - y) / prediction**2) / len(y)
        else:
            loss_gradient = log_f.T @ (1.0 - y / prediction) / len(y)
        return loss_gradient + 2.0 * penalty * (weights - equal)

    result = minimize(
        objective,
        start,
        jac=gradient,
        method="SLSQP",
        bounds=[(0.0, 1.0)] * n_experts,
        constraints=[
            {
                "type": "eq",
                "fun": lambda weights: float(weights.sum() - 1.0),
                "jac": lambda weights: np.ones_like(weights),
            }
        ],
        options={"ftol": 1e-11, "maxiter": 300, "disp": False},
    )
    if not result.success:
        raise RuntimeError(f"QLIKE stacking failed: {result.message}")
    weights = np.clip(np.asarray(result.x, dtype=float), 0.0, 1.0)
    weights /= weights.sum()
    return weights, {
        "optimizer_success": bool(result.success),
        "optimizer_iterations": int(result.nit),
        "training_objective": objective(weights),
    }


def quarterly_maturity_safe_stacking(
    frame: pd.DataFrame,
    experts: pd.DataFrame,
    penalty: float,
    window: int | None,
    combination: str,
    prediction_start: str = "2007-01-01",
    minimum_training: int = 252,
) -> tuple[pd.Series, pd.DataFrame, pd.DataFrame]:
    output = pd.Series(np.nan, index=frame.index, name="stacked_forecast")
    audit_rows: list[dict[str, Any]] = []
    weight_rows: list[dict[str, Any]] = []
    prediction_index = frame.loc[prediction_start:].index
    grouped = pd.Series(prediction_index, index=prediction_index).groupby(prediction_index.to_period("Q"))
    previous_weights: np.ndarray | None = None
    for _, group in grouped:
        dates = pd.DatetimeIndex(group.to_numpy())
        refit_date = dates[0]
        eligible_mask = (
            frame["future_variance"].notna()
            & frame["target_end"].notna()
            & (frame["target_end"] < refit_date)
            & experts.notna().all(axis=1)
        )
        eligible_index = frame.index[eligible_mask]
        if window is not None:
            eligible_index = eligible_index[-window:]
        if len(eligible_index) < minimum_training:
            continue
        weights, optimizer = fit_qlike_stacking_weights(
            frame.loc[eligible_index, "future_variance"].to_numpy(),
            experts.loc[eligible_index].to_numpy(),
            penalty,
            combination,
            previous_weights,
        )
        current_experts = experts.loc[dates]
        if combination == "arithmetic":
            prediction = current_experts.to_numpy() @ weights
        else:
            prediction = np.exp(np.log(current_experts.to_numpy()) @ weights)
        output.loc[dates] = prediction
        previous_weights = weights
        audit_rows.append(
            {
                "refit_date": refit_date,
                "prediction_period_end": dates[-1],
                "training_origin_start": eligible_index[0],
                "training_origin_end": eligible_index[-1],
                "latest_training_target_end": frame.loc[eligible_index, "target_end"].max(),
                "n_training_labels": len(eligible_index),
                "all_training_labels_matured": bool(
                    frame.loc[eligible_index, "target_end"].max() < refit_date
                ),
                "window": "expanding" if window is None else window,
                "penalty": penalty,
                "combination": combination,
                **optimizer,
            }
        )
        weight_rows.append(
            {
                "refit_date": refit_date,
                **{column: weight for column, weight in zip(experts.columns, weights)},
            }
        )
    return output.clip(lower=0.002, upper=3.0), pd.DataFrame(audit_rows), pd.DataFrame(weight_rows)


def select_stacking_model(
    frame: pd.DataFrame,
    experts: pd.DataFrame,
    validation_start: str,
    validation_end: str,
) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    cache: dict[tuple[float, int | None, str], tuple[pd.Series, pd.DataFrame, pd.DataFrame]] = {}
    for penalty in (0.0, 0.01, 0.10, 1.0):
        for window in (756, 1512, None):
            for combination in ("arithmetic", "geometric"):
                prediction, audit, weights = quarterly_maturity_safe_stacking(
                    frame,
                    experts,
                    penalty,
                    window,
                    combination,
                )
                cache[(penalty, window, combination)] = (prediction, audit, weights)
                metrics = forecast_metrics(frame, prediction, validation_start, validation_end)
                rows.append(
                    {
                        "penalty": penalty,
                        "window": "expanding" if window is None else window,
                        "window_value": np.nan if window is None else window,
                        "combination": combination,
                        **{f"validation_{name}": value for name, value in metrics.items()},
                    }
                )
    selection = pd.DataFrame(rows).sort_values(
        ["validation_qlike", "validation_log_rmse", "penalty"], ignore_index=True
    )
    winner = selection.iloc[0]
    selected_window = None if str(winner.window) == "expanding" else int(winner.window_value)
    key = (float(winner.penalty), selected_window, str(winner.combination))
    prediction, audit, weights = cache[key]
    configuration = {
        "penalty": key[0],
        "window": "expanding" if key[1] is None else key[1],
        "combination": key[2],
    }
    return selection, prediction, audit, weights, configuration


def development_qlike_loss_cap(
    frame: pd.DataFrame,
    experts: pd.DataFrame,
    start: str,
    end: str,
    quantile: float = 0.99,
) -> float:
    index = frame.loc[start:end].dropna(subset=["future_variance"]).index.intersection(
        experts.dropna().index
    )
    losses = qlike_loss(
        frame.loc[index, "future_variance"].to_numpy()[:, None],
        experts.loc[index].to_numpy(),
    )
    return float(np.quantile(losses, quantile))


def quarterly_regret_calibrated_hedge(
    frame: pd.DataFrame,
    experts: pd.DataFrame,
    loss_cap: float,
    window: int = 504,
    prediction_start: str = "2007-01-01",
    minimum_training: int = 252,
) -> tuple[pd.Series, pd.DataFrame, pd.DataFrame]:
    """Aggregate forecasts with a regret-calibrated exponential update.

    The cap is estimated once from the development period.  At each quarterly
    refit, QLIKE losses from the most recent two years of fully matured labels are
    clipped at that cap.  The learning rate

        eta = sqrt(8 log(K) / (n * loss_cap^2))

    is the standard bounded-loss Hedge rate, so no learning-rate grid is tuned.
    The resulting arithmetic mixture is deterministic and positive.
    """
    output = pd.Series(np.nan, index=frame.index, name="hedge_forecast")
    audit_rows: list[dict[str, Any]] = []
    weight_rows: list[dict[str, Any]] = []
    prediction_index = frame.loc[prediction_start:].index
    grouped = pd.Series(prediction_index, index=prediction_index).groupby(prediction_index.to_period("Q"))
    for _, group in grouped:
        dates = pd.DatetimeIndex(group.to_numpy())
        refit_date = dates[0]
        eligible_mask = (
            frame["future_variance"].notna()
            & frame["target_end"].notna()
            & (frame["target_end"] < refit_date)
            & experts.notna().all(axis=1)
        )
        eligible_index = frame.index[eligible_mask][-window:]
        if len(eligible_index) < minimum_training:
            continue
        actual = frame.loc[eligible_index, "future_variance"].to_numpy()[:, None]
        expert_values = experts.loc[eligible_index].to_numpy()
        losses = np.minimum(qlike_loss(actual, expert_values), loss_cap)
        learning_rate = math.sqrt(
            8.0 * math.log(experts.shape[1]) / (len(eligible_index) * loss_cap**2)
        )
        log_weights = -learning_rate * losses.sum(axis=0)
        log_weights -= log_weights.max()
        weights = np.exp(log_weights)
        weights /= weights.sum()
        output.loc[dates] = experts.loc[dates].to_numpy() @ weights
        audit_rows.append(
            {
                "refit_date": refit_date,
                "prediction_period_end": dates[-1],
                "training_origin_start": eligible_index[0],
                "training_origin_end": eligible_index[-1],
                "latest_training_target_end": frame.loc[eligible_index, "target_end"].max(),
                "n_training_labels": len(eligible_index),
                "loss_cap": loss_cap,
                "learning_rate_on_cumulative_loss": learning_rate,
                "effective_learning_rate_on_mean_loss": learning_rate * len(eligible_index),
                "all_training_labels_matured": bool(
                    frame.loc[eligible_index, "target_end"].max() < refit_date
                ),
            }
        )
        weight_rows.append(
            {
                "refit_date": refit_date,
                **{column: weight for column, weight in zip(experts.columns, weights)},
            }
        )
    return output.clip(lower=0.002, upper=3.0), pd.DataFrame(audit_rows), pd.DataFrame(weight_rows)


def empirical_upper_quantile(values: np.ndarray, quantile: float) -> float:
    return float(np.quantile(np.asarray(values, dtype=float), quantile, method="higher"))


def interlaced_upper_bound(
    frame: pd.DataFrame,
    point_forecast: pd.Series,
    mode: str,
    window: int,
    local_k: int | None = None,
    quantile: float = 0.90,
    minimum_scores: int = 20,
    prediction_start: str = "2009-01-01",
) -> tuple[pd.Series, pd.DataFrame]:
    """Maturity-safe upper bound with optional non-overlapping score streams.

    For the interlaced modes, forecast origins in a stream are 22 trading days
    apart.  Their 22-day targets therefore do not overlap.  A current origin is
    calibrated only with scores whose target ended strictly before that origin.
    ``interlaced_local`` additionally retains the closest historical log-VIX
    states inside the same stream.
    """
    upper = pd.Series(np.nan, index=frame.index, name="upper_predictive_bound")
    residual = frame["log_future_variance"] - np.log(point_forecast)
    valid = residual.notna().to_numpy()
    streams = frame["interlaced_stream"].to_numpy(dtype=int)
    log_vix = np.log(frame["vix"].to_numpy(dtype=float))
    dates = frame.index
    start_position = int(np.searchsorted(dates.to_numpy(), np.datetime64(prediction_start)))
    audit_rows: list[dict[str, Any]] = []
    for position in range(start_position, len(frame)):
        if not np.isfinite(point_forecast.iloc[position]):
            continue
        latest_allowed_origin = position - HORIZON - 1
        if latest_allowed_origin < 0:
            continue
        eligible = np.flatnonzero(valid[: latest_allowed_origin + 1])
        if mode.startswith("interlaced"):
            eligible = eligible[streams[eligible] == streams[position]]
        if len(eligible) > window:
            eligible = eligible[-window:]
        if mode == "interlaced_local":
            if local_k is None:
                raise ValueError("Local calibration requires local_k.")
            if len(eligible) > local_k:
                distances = np.abs(log_vix[eligible] - log_vix[position])
                keep = np.argpartition(distances, local_k - 1)[:local_k]
                eligible = np.sort(eligible[keep])
        if len(eligible) < minimum_scores:
            continue
        score_quantile = empirical_upper_quantile(
            residual.iloc[eligible].to_numpy(),
            quantile,
        )
        upper.iloc[position] = float(point_forecast.iloc[position] * math.exp(score_quantile))
        latest_target_end = frame.iloc[eligible]["target_end"].max()
        audit_rows.append(
            {
                "forecast_date": dates[position],
                "mode": mode,
                "stream": int(streams[position]),
                "calibration_origin_start": dates[eligible[0]],
                "calibration_origin_end": dates[eligible[-1]],
                "latest_calibration_target_end": latest_target_end,
                "n_calibration_scores": len(eligible),
                "score_quantile": score_quantile,
                "all_calibration_labels_matured": bool(latest_target_end < dates[position]),
                "same_stream_only": bool(
                    not mode.startswith("interlaced")
                    or np.all(streams[eligible] == streams[position])
                ),
                "nonoverlapping_within_stream": bool(
                    not mode.startswith("interlaced")
                    or len(eligible) < 2
                    or np.all(np.diff(eligible) >= HORIZON)
                ),
                "window": window,
                "local_k": local_k,
            }
        )
    return upper, pd.DataFrame(audit_rows)


def select_calibration(
    frame: pd.DataFrame,
    point_forecast: pd.Series,
    validation_start: str,
    validation_end: str,
) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame, dict[str, Any]]:
    configurations = [
        {"mode": "pooled", "window": window, "local_k": None}
        for window in (504, 756, 1512)
    ]
    configurations += [
        {"mode": "interlaced", "window": window, "local_k": None}
        for window in (63, 126, 252)
    ]
    configurations += [
        {"mode": "interlaced_local", "window": 252, "local_k": local_k}
        for local_k in (30, 50, 80)
    ]
    rows: list[dict[str, Any]] = []
    cache: dict[tuple[str, int, int | None], tuple[pd.Series, pd.DataFrame]] = {}
    quantile = 0.90
    for configuration in configurations:
        key = (configuration["mode"], configuration["window"], configuration["local_k"])
        upper, audit = interlaced_upper_bound(frame, point_forecast, **configuration)
        cache[key] = (upper, audit)
        sample = pd.concat(
            [
                np.log(frame["future_variance"]).rename("actual"),
                np.log(point_forecast).rename("point"),
                np.log(upper).rename("upper"),
            ],
            axis=1,
        ).loc[validation_start:validation_end].dropna()
        error = sample["actual"] - sample["upper"]
        pinball = np.maximum(quantile * error, (quantile - 1.0) * error)
        rows.append(
            {
                **configuration,
                "validation_n_evaluable": int(len(sample)),
                "validation_pinball_loss": float(pinball.mean()),
                "validation_coverage": float((error <= 0.0).mean()),
                "validation_mean_log_upper_to_point": float((sample["upper"] - sample["point"]).mean()),
            }
        )
    selection = pd.DataFrame(rows).sort_values(
        ["validation_pinball_loss", "validation_mean_log_upper_to_point"],
        ignore_index=True,
    )
    winner = selection.iloc[0]
    local_k = None if pd.isna(winner.local_k) else int(winner.local_k)
    key = (str(winner["mode"]), int(winner.window), local_k)
    upper, audit = cache[key]
    return selection, upper, audit, {
        "mode": key[0],
        "window": key[1],
        "local_k": key[2],
        "nominal_quantile": quantile,
    }


def simulate_total_return_strategy(
    exposure: pd.Series,
    next_total_return: pd.Series,
    cash_return: pd.Series,
    cost_bps: float,
) -> StrategySimulation:
    aligned = pd.concat(
        [
            exposure.rename("exposure"),
            next_total_return.rename("asset_return"),
            cash_return.rename("cash_return"),
        ],
        axis=1,
    ).dropna()
    turnover = aligned["exposure"].diff().abs().fillna(0.0)
    strategy_return = (
        aligned["exposure"] * aligned["asset_return"]
        + (1.0 - aligned["exposure"]) * aligned["cash_return"]
        - cost_bps / 10_000.0 * turnover
    )
    strategy_return.name = "strategy_return"
    return StrategySimulation(
        strategy_return,
        turnover,
        aligned["exposure"],
        aligned["cash_return"],
    )


def strategy_metrics(
    simulation: StrategySimulation,
    index: pd.DatetimeIndex,
) -> dict[str, float | int | str]:
    metrics = performance_metrics(
        simulation.returns.reindex(index),
        turnover=simulation.turnover.reindex(index),
        exposure=simulation.exposure.reindex(index),
    )
    returns = simulation.returns.reindex(index).dropna()
    cash = simulation.cash_return.reindex(returns.index)
    excess = returns - cash
    metrics["sharpe_over_cash"] = float(
        excess.mean() / returns.std(ddof=1) * math.sqrt(TRADING_DAYS)
    )
    metrics["certainty_equivalent_gamma3"] = float(
        returns.mean() * TRADING_DAYS
        - 0.5 * 3.0 * returns.var(ddof=1) * TRADING_DAYS
    )
    return metrics


def scale_to_mean_exposure(
    variance_signal: pd.Series,
    target_mean: float,
    validation_index: pd.DatetimeIndex,
    minimum: float = 0.2,
    maximum: float = 1.5,
) -> float:
    low, high = 0.001, 1.0
    for _ in range(80):
        middle = 0.5 * (low + high)
        mean = float((middle / np.sqrt(variance_signal)).clip(minimum, maximum).reindex(validation_index).mean())
        if mean < target_mean:
            low = middle
        else:
            high = middle
    return 0.5 * (low + high)


def coverage_by_regime(
    frame: pd.DataFrame,
    upper: pd.Series,
    validation_start: str,
    validation_end: str,
    confirmation_start: str,
    confirmation_end: str,
) -> pd.DataFrame:
    validation_vix = frame.loc[validation_start:validation_end, "vix"].dropna()
    cutpoints = validation_vix.quantile([0.2, 0.4, 0.6, 0.8]).to_numpy()
    sample = pd.DataFrame(
        {
            "actual": frame["future_variance"],
            "upper": upper,
            "vix": frame["vix"],
        }
    ).loc[confirmation_start:confirmation_end].dropna()
    sample["regime"] = pd.cut(
        sample["vix"],
        bins=np.r_[-np.inf, cutpoints, np.inf],
        labels=["Q1_low", "Q2", "Q3", "Q4", "Q5_high"],
    )
    rows: list[dict[str, Any]] = []
    for regime, group in sample.groupby("regime", observed=True):
        rows.append(
            {
                "validation_vix_regime": str(regime),
                "n_forecasts": int(len(group)),
                "vix_min": float(group["vix"].min()),
                "vix_max": float(group["vix"].max()),
                "empirical_upper_coverage": float((group["actual"] <= group["upper"]).mean()),
            }
        )
    return pd.DataFrame(rows)


def make_plots(
    output_dir: Path,
    frame: pd.DataFrame,
    experts: pd.DataFrame,
    hedge_weights: pd.DataFrame,
    simulations: dict[str, StrategySimulation],
    common_confirmation_index: pd.DatetimeIndex,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    labels = {
        "distributional_bound": "Distributional bound",
        "vix_matched_exposure": "VIX matched exposure",
        "fixed_exposure": "Fixed exposure",
        "buy_and_hold": "SPY buy-and-hold",
    }
    fig, axes = plt.subplots(2, 1, figsize=(10.5, 7.0), sharex=True, gridspec_kw={"height_ratios": [2, 1]})
    for name, label in labels.items():
        returns = simulations[name].returns.reindex(common_confirmation_index).dropna()
        axes[0].plot((1.0 + returns).cumprod(), label=label, linewidth=1.3)
        axes[1].plot(drawdown_series(returns), label=label, linewidth=1.1)
    axes[0].set_title("Confirmation sample: SPY total-return risk control (2013–2026)")
    axes[0].set_ylabel("Growth of $1")
    axes[0].legend(ncol=2, frameon=False)
    axes[0].grid(alpha=0.2)
    axes[1].set_ylabel("Drawdown")
    axes[1].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "confirmation_wealth_and_drawdown.png", dpi=180)
    plt.close(fig)

    forecast = frame.loc["2020":].dropna(
        subset=["future_variance", "hedge_forecast", "upper_predictive_bound"]
    )
    fig, ax = plt.subplots(figsize=(10.5, 4.8))
    ax.plot(np.sqrt(forecast["future_variance"]), label="Future 22-day realized volatility", linewidth=1.15)
    ax.plot(np.sqrt(forecast["hedge_forecast"]), label="Maturity-safe Hedge forecast", linewidth=1.0)
    ax.plot(np.sqrt(forecast["upper_predictive_bound"]), label="90% upper bound", linewidth=1.0)
    ax.set_title("Distributional volatility forecast")
    ax.set_ylabel("Annualized volatility")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "forecast_and_upper_bound.png", dpi=180)
    plt.close(fig)

    if not hedge_weights.empty:
        weights = hedge_weights.set_index("refit_date")
        fig, ax = plt.subplots(figsize=(10.5, 4.8))
        ax.stackplot(weights.index, *[weights[column] for column in experts.columns], labels=list(experts.columns), alpha=0.85)
        ax.set_ylim(0.0, 1.0)
        ax.set_ylabel("Expert weight")
        ax.set_title("Bounded-loss Hedge expert weights")
        ax.legend(ncol=3, frameon=False, fontsize=8)
        fig.tight_layout()
        fig.savefig(output_dir / "hedge_expert_weights.png", dpi=180)
        plt.close(fig)

    coverage_flag = (
        frame["future_variance"] <= frame["upper_predictive_bound"]
    ).where(frame[["future_variance", "upper_predictive_bound"]].notna().all(axis=1))
    rolling = coverage_flag.loc["2013":].rolling(252, min_periods=126).mean()
    fig, ax = plt.subplots(figsize=(10.5, 4.3))
    ax.plot(rolling, linewidth=1.15)
    ax.axhline(0.90, color="black", linestyle="--", linewidth=1.0, label="Nominal 90%")
    ax.set_ylim(0.60, 1.01)
    ax.set_ylabel("Rolling coverage")
    ax.set_title("One-year empirical coverage")
    ax.legend(frameon=False)
    ax.grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "confirmation_rolling_coverage.png", dpi=180)
    plt.close(fig)


def run(
    spx_json: Path,
    vix_csv: Path,
    spy_json: Path,
    risk_free_csv: Path,
    output_dir: Path,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    frame = build_extended_frame(spx_json, vix_csv, spy_json, risk_free_csv)
    development_start, development_end = "2005-01-01", "2008-12-31"
    validation_start, validation_end = "2009-01-01", "2012-12-31"
    confirmation_start, confirmation_end = "2013-01-01", str(frame.index[-1].date())

    base_selection, experts, chosen_experts = select_base_experts(
        frame,
        development_start,
        development_end,
    )
    loss_cap = development_qlike_loss_cap(
        frame,
        experts,
        development_start,
        development_end,
        quantile=0.99,
    )
    point_forecast, hedge_audit, hedge_weights = quarterly_regret_calibrated_hedge(
        frame,
        experts,
        loss_cap=loss_cap,
        window=504,
    )
    hedge_configuration = {
        "method": "bounded-loss Hedge",
        "window": 504,
        "loss_cap": loss_cap,
        "loss_cap_source": "99th percentile of expert QLIKE losses on 2005–2008 development data",
        "learning_rate": "sqrt(8 log(K) / (n * loss_cap^2)); not tuned",
        "combination": "arithmetic",
    }
    frame["hedge_forecast"] = point_forecast
    calibration_selection, _, _, validation_best_calibration = select_calibration(
        frame,
        point_forecast,
        validation_start,
        validation_end,
    )
    # The primary calibration is fixed by the dependence structure, rather than
    # chosen by the lowest pooled validation loss.  Sixty-three scores per stream
    # correspond to roughly 5.5 years of non-overlapping 22-day targets and retain
    # adaptation while avoiding target overlap within every calibration sequence.
    upper, calibration_audit = interlaced_upper_bound(
        frame,
        point_forecast,
        mode="interlaced",
        window=63,
        local_k=None,
        quantile=0.90,
    )
    calibration_configuration = {
        "mode": "interlaced",
        "scores_per_stream": 63,
        "number_of_streams": HORIZON,
        "nominal_quantile": 0.90,
        "selection_rule": "fixed by overlapping-target design; not selected on confirmation performance",
        "validation_pinball_best_sensitivity": validation_best_calibration,
    }
    frame["upper_predictive_bound"] = upper

    forecast_confirmation = {
        "hedge_ensemble": forecast_metrics(
            frame,
            point_forecast,
            confirmation_start,
            confirmation_end,
        ),
        "raw_vix_variance": forecast_metrics(
            frame,
            frame["implied_variance"],
            confirmation_start,
            confirmation_end,
        ),
        "trailing_22d_variance": forecast_metrics(
            frame,
            frame["trailing_variance_22d"],
            confirmation_start,
            confirmation_end,
        ),
    }
    forecast_validation = {
        "hedge_ensemble": forecast_metrics(frame, point_forecast, validation_start, validation_end),
        "raw_vix_variance": forecast_metrics(frame, frame["implied_variance"], validation_start, validation_end),
    }
    dm_sample = pd.DataFrame(
        {
            "actual": frame["future_variance"],
            "hedge": point_forecast,
            "vix": frame["implied_variance"],
        }
    ).loc[confirmation_start:confirmation_end].dropna()
    qlike_difference = qlike_loss(dm_sample["actual"], dm_sample["hedge"]) - qlike_loss(
        dm_sample["actual"], dm_sample["vix"]
    )
    hedge_log_error = np.log(dm_sample["actual"]) - np.log(dm_sample["hedge"])
    vix_log_error = np.log(dm_sample["actual"]) - np.log(dm_sample["vix"])
    forecast_inference = {
        "qlike_hedge_minus_vix": newey_west_mean_test(qlike_difference, lags=HORIZON - 1),
        "squared_log_error_hedge_minus_vix": newey_west_mean_test(
            hedge_log_error.to_numpy() ** 2 - vix_log_error.to_numpy() ** 2,
            lags=HORIZON - 1,
        ),
    }

    coverage_sample = pd.DataFrame(
        {"actual": frame["future_variance"], "upper": upper, "point": point_forecast}
    ).loc[confirmation_start:confirmation_end].dropna()
    coverage = {
        "n_evaluable_forecasts": int(len(coverage_sample)),
        "empirical_upper_coverage": float((coverage_sample["actual"] <= coverage_sample["upper"]).mean()),
        "mean_upper_to_point_ratio": float((coverage_sample["upper"] / coverage_sample["point"]).mean()),
    }
    regime_coverage = coverage_by_regime(
        frame,
        upper,
        validation_start,
        validation_end,
        confirmation_start,
        confirmation_end,
    )

    target_volatility = 0.12
    minimum_exposure, maximum_exposure = 0.2, 1.5
    exposure: dict[str, pd.Series] = {
        "buy_and_hold": pd.Series(1.0, index=frame.index),
        "standard_vix_target": (
            target_volatility / np.sqrt(frame["implied_variance"])
        ).clip(minimum_exposure, maximum_exposure),
        "point_forecast_target": (
            target_volatility / np.sqrt(point_forecast)
        ).clip(minimum_exposure, maximum_exposure),
        "distributional_bound": (
            target_volatility / np.sqrt(upper)
        ).clip(minimum_exposure, maximum_exposure),
    }
    validation_available = exposure["distributional_bound"].loc[validation_start:validation_end].dropna().index
    fixed_exposure = float(exposure["distributional_bound"].reindex(validation_available).mean())
    exposure["fixed_exposure"] = pd.Series(fixed_exposure, index=frame.index)
    matched_scale = scale_to_mean_exposure(
        frame["implied_variance"],
        fixed_exposure,
        validation_available,
        minimum_exposure,
        maximum_exposure,
    )
    exposure["vix_matched_exposure"] = (
        matched_scale / np.sqrt(frame["implied_variance"])
    ).clip(minimum_exposure, maximum_exposure)
    confirmation_available = exposure["distributional_bound"].loc[
        confirmation_start:confirmation_end
    ].dropna().index
    confirmation_mean_exposure = float(
        exposure["distributional_bound"].reindex(confirmation_available).mean()
    )
    attribution_scale = scale_to_mean_exposure(
        frame["implied_variance"],
        confirmation_mean_exposure,
        confirmation_available,
        minimum_exposure,
        maximum_exposure,
    )
    exposure["vix_expost_matched_exposure_attribution"] = (
        attribution_scale / np.sqrt(frame["implied_variance"])
    ).clip(minimum_exposure, maximum_exposure)

    simulations = {
        name: simulate_total_return_strategy(
            signal,
            frame["next_spy_total_return"],
            frame["cash_return"],
            cost_bps=1.0,
        )
        for name, signal in exposure.items()
    }
    common_confirmation_index = simulations["distributional_bound"].returns.loc[
        confirmation_start:confirmation_end
    ].index
    common_validation_index = simulations["distributional_bound"].returns.loc[
        validation_start:validation_end
    ].index
    confirmation_strategy_metrics = {
        name: strategy_metrics(simulation, common_confirmation_index)
        for name, simulation in simulations.items()
    }
    validation_strategy_metrics = {
        name: strategy_metrics(simulation, common_validation_index)
        for name, simulation in simulations.items()
    }

    cost_rows: list[dict[str, Any]] = []
    for cost_bps in (0.0, 1.0, 5.0, 10.0):
        simulation = simulate_total_return_strategy(
            exposure["distributional_bound"],
            frame["next_spy_total_return"],
            frame["cash_return"],
            cost_bps,
        )
        cost_rows.append(
            {
                "cost_bps_per_exposure_change": cost_bps,
                **strategy_metrics(simulation, common_confirmation_index),
            }
        )
    cost_sensitivity = pd.DataFrame(cost_rows)

    bootstrap_vs_fixed = paired_moving_block_bootstrap(
        simulations["distributional_bound"].returns.reindex(common_confirmation_index),
        simulations["fixed_exposure"].returns.reindex(common_confirmation_index),
    )
    bootstrap_vs_vix = paired_moving_block_bootstrap(
        simulations["distributional_bound"].returns.reindex(common_confirmation_index),
        simulations["vix_matched_exposure"].returns.reindex(common_confirmation_index),
    )
    bootstrap_vs_expost_matched_vix = paired_moving_block_bootstrap(
        simulations["distributional_bound"].returns.reindex(common_confirmation_index),
        simulations["vix_expost_matched_exposure_attribution"].returns.reindex(
            common_confirmation_index
        ),
    )

    subperiod_rows: list[dict[str, Any]] = []
    for period, start, end in (
        ("2013_2019", "2013-01-01", "2019-12-31"),
        ("2020_2026", "2020-01-01", confirmation_end),
    ):
        period_index = common_confirmation_index[
            (common_confirmation_index >= start) & (common_confirmation_index <= end)
        ]
        for name, simulation in simulations.items():
            subperiod_rows.append(
                {"period": period, "strategy": name, **strategy_metrics(simulation, period_index)}
            )
    subperiod_metrics = pd.DataFrame(subperiod_rows)

    base_selection.to_csv(output_dir / "base_model_development_grid.csv", index=False)
    calibration_selection.to_csv(output_dir / "calibration_validation_sensitivity.csv", index=False)
    hedge_audit.to_csv(output_dir / "hedge_maturity_audit.csv", index=False)
    hedge_weights.to_csv(output_dir / "hedge_expert_weights.csv", index=False)
    calibration_audit.to_csv(output_dir / "calibration_maturity_and_overlap_audit.csv", index=False)
    pd.DataFrame(forecast_validation).T.to_csv(output_dir / "validation_forecast_metrics.csv")
    pd.DataFrame(forecast_confirmation).T.to_csv(output_dir / "confirmation_forecast_metrics.csv")
    pd.DataFrame(validation_strategy_metrics).T.to_csv(output_dir / "validation_strategy_metrics.csv")
    pd.DataFrame(confirmation_strategy_metrics).T.to_csv(output_dir / "confirmation_strategy_metrics.csv")
    regime_coverage.to_csv(output_dir / "confirmation_coverage_by_validation_vix_regime.csv", index=False)
    cost_sensitivity.to_csv(output_dir / "cost_sensitivity.csv", index=False)
    subperiod_metrics.to_csv(output_dir / "subperiod_metrics.csv", index=False)
    frame[
        [
            "future_variance",
            "target_end",
            "implied_variance",
            "trailing_variance_22d",
            "ewma_variance_094",
            "hedge_forecast",
            "upper_predictive_bound",
            "next_spy_total_return",
            "cash_return",
            "interlaced_stream",
        ]
    ].to_csv(output_dir / "forecast_panel.csv", index_label="date")
    strategy_daily = pd.DataFrame(index=common_confirmation_index)
    for name, simulation in simulations.items():
        strategy_daily[f"{name}_return"] = simulation.returns
        strategy_daily[f"{name}_exposure"] = simulation.exposure
        strategy_daily[f"{name}_turnover"] = simulation.turnover
    strategy_daily.to_csv(output_dir / "confirmation_strategy_daily.csv", index_label="forecast_date")
    make_plots(
        output_dir,
        frame,
        experts,
        hedge_weights,
        simulations,
        common_confirmation_index,
    )

    robust = confirmation_strategy_metrics["distributional_bound"]
    buy_hold = confirmation_strategy_metrics["buy_and_hold"]
    fixed = confirmation_strategy_metrics["fixed_exposure"]
    matched_vix = confirmation_strategy_metrics["vix_matched_exposure"]
    attribution_vix = confirmation_strategy_metrics["vix_expost_matched_exposure_attribution"]
    headline = {
        "log_rmse_improvement_vs_raw_vix": float(
            1.0
            - forecast_confirmation["hedge_ensemble"]["log_rmse"]
            / forecast_confirmation["raw_vix_variance"]["log_rmse"]
        ),
        "qlike_improvement_vs_raw_vix": float(
            1.0
            - forecast_confirmation["hedge_ensemble"]["qlike"]
            / forecast_confirmation["raw_vix_variance"]["qlike"]
        ),
        "max_drawdown_improvement_vs_buy_hold_points": float(
            robust["max_drawdown"] - buy_hold["max_drawdown"]
        ),
        "max_drawdown_improvement_vs_fixed_exposure_points": float(
            robust["max_drawdown"] - fixed["max_drawdown"]
        ),
        "max_drawdown_improvement_vs_vix_matched_exposure_points": float(
            robust["max_drawdown"] - matched_vix["max_drawdown"]
        ),
        "max_drawdown_improvement_vs_expost_equal_exposure_vix_points": float(
            robust["max_drawdown"] - attribution_vix["max_drawdown"]
        ),
    }
    results: dict[str, Any] = {
        "project": "Maturity-Safe Distributional Volatility Forecasting and Risk Control",
        "data": {
            "spx_source_file": spx_json.name,
            "vix_source_file": vix_csv.name,
            "spy_total_return_source_file": spy_json.name,
            "risk_free_source_file": risk_free_csv.name,
            "start": str(frame.index[0].date()),
            "end": str(frame.index[-1].date()),
            "n_aligned_forecast_origins": int(len(frame)),
        },
        "research_contribution": (
            "A QLIKE-trained online ensemble admits only matured overlapping-horizon labels; "
            "its upper variance forecast is calibrated with 22 interlaced residual streams "
            "whose targets do not overlap within stream."
        ),
        "protocol": {
            "base_model_development_period": [development_start, development_end],
            "ensemble_sensitivity_and_calibration_validation_period": [validation_start, validation_end],
            "confirmation_period": [confirmation_start, confirmation_end],
            "forecast_horizon_trading_days": HORIZON,
            "strict_label_maturity": "target end must be strictly earlier than every model refit or calibration date",
            "target_volatility": target_volatility,
            "exposure_clip": [minimum_exposure, maximum_exposure],
            "transaction_cost": "1 bp times absolute change in SPY exposure",
            "cash_and_borrowing": "3-month Treasury constant-maturity yield converted to a daily return",
            "economic_instrument": "SPY adjusted close, including distributions in the saved Yahoo series",
        },
        "selected_base_experts": chosen_experts,
        "selected_online_ensemble_configuration": hedge_configuration,
        "primary_calibration_configuration": calibration_configuration,
        "matched_benchmarks": {
            "fixed_validation_exposure": fixed_exposure,
            "vix_scale_matched_to_validation_mean_exposure": matched_scale,
            "attribution_only_confirmation_mean_exposure": confirmation_mean_exposure,
            "attribution_only_vix_scale_matched_expost": attribution_scale,
            "attribution_warning": "The ex-post equal-exposure VIX series is a diagnostic, not a deployable benchmark selected before the confirmation period.",
        },
        "validation_forecast_metrics": forecast_validation,
        "confirmation_forecast_metrics": forecast_confirmation,
        "forecast_loss_inference": forecast_inference,
        "confirmation_upper_bound_coverage": coverage,
        "confirmation_coverage_by_validation_vix_regime": regime_coverage.to_dict(orient="records"),
        "validation_strategy_metrics": validation_strategy_metrics,
        "confirmation_strategy_metrics": confirmation_strategy_metrics,
        "confirmation_headline": headline,
        "bootstrap_vs_fixed_exposure": bootstrap_vs_fixed,
        "bootstrap_vs_vix_matched_exposure": bootstrap_vs_vix,
        "bootstrap_vs_expost_equal_exposure_vix_attribution": bootstrap_vs_expost_matched_vix,
        "limitations": [
            "The volatility target uses daily close-to-close SPX returns rather than intraday realized measures.",
            "VIX is an information variable and benchmark, not a tradable spot position.",
            "The interlaced residual streams remove target overlap within stream but do not create an exchangeability guarantee under market nonstationarity.",
            "SPY adjusted-close execution omits bid-ask variation, taxes, futures roll, and market impact.",
            "Borrowing and lending use the same Treasury proxy; real leveraged financing would be more expensive.",
            "The 2013–2026 period is called confirmation because an earlier, materially different model was already inspected on these dates.",
        ],
    }
    write_json(output_dir / "results.json", results)
    return results
