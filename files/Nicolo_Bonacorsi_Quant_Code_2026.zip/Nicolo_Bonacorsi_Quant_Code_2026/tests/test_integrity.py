from __future__ import annotations

import json
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize

from quant_projects.distributional_volatility import (
    build_extended_frame,
    simulate_total_return_strategy,
)
from quant_projects.dro_allocation import (
    bootstrap_directional_upper_covariances,
    solve_turnover_aware_minimum_variance,
)
from quant_projects.robust_allocation import (
    load_ff25_aggregated_daily,
    project_capped_simplex,
)
from quant_projects.volatility_control import build_forecast_frame, load_spx_vix


ROOT = Path(__file__).resolve().parents[1]


class TestCoreInvariants(unittest.TestCase):
    def test_capped_simplex_projection(self) -> None:
        values = np.array([-2.0, 0.5, 1.5, 9.0, -0.2])
        weights = project_capped_simplex(values, cap=0.4)
        self.assertAlmostEqual(float(weights.sum()), 1.0, places=12)
        self.assertGreaterEqual(float(weights.min()), -1e-12)
        self.assertLessEqual(float(weights.max()), 0.4 + 1e-12)

    def test_active_set_qp_matches_generic_reference(self) -> None:
        rng = np.random.default_rng(19)
        loading = rng.normal(size=(12, 12))
        covariance = loading @ loading.T / 12.0 + 0.02 * np.eye(12)
        reference = rng.dirichlet(np.ones(12))
        cap = 0.20
        penalty = 0.5
        weights, diagnostics = solve_turnover_aware_minimum_variance(
            covariance,
            reference,
            cap,
            penalty,
        )
        scale = np.trace(covariance) / len(covariance)
        normalized = covariance / scale

        def objective(candidate: np.ndarray) -> float:
            return float(
                candidate @ normalized @ candidate
                + penalty * np.sum((candidate - reference) ** 2)
            )

        reference_fit = minimize(
            objective,
            project_capped_simplex(reference, cap),
            method="SLSQP",
            bounds=[(0.0, cap)] * len(reference),
            constraints=[{"type": "eq", "fun": lambda candidate: candidate.sum() - 1.0}],
            options={"ftol": 1e-12, "maxiter": 500},
        )
        self.assertTrue(reference_fit.success)
        self.assertTrue(diagnostics["optimizer_success"])
        self.assertLessEqual(abs(objective(weights) - objective(reference_fit.x)), 1e-9)
        self.assertAlmostEqual(float(weights.sum()), 1.0, places=11)
        self.assertGreaterEqual(float(weights.min()), -1e-10)
        self.assertLessEqual(float(weights.max()), cap + 1e-9)

    def test_bootstrap_upper_covariance_is_psd_and_trace_inflating(self) -> None:
        rng = np.random.default_rng(7)
        observations = rng.normal(size=(252, 10)) @ rng.normal(size=(10, 10))
        sample, upper, diagnostics = bootstrap_directional_upper_covariances(
            observations,
            (0.75, 0.90),
            block_length=21,
            replications=64,
            seed=11,
        )
        for covariance in upper.values():
            self.assertGreater(float(np.linalg.eigvalsh(covariance).min()), -1e-10)
            self.assertGreaterEqual(float(np.trace(covariance)), float(np.trace(sample)) - 1e-10)
        self.assertGreaterEqual(int(diagnostics["n_eigenvalues_above_mp_edge"]), 0)

    def test_ff25_panel_is_complete_and_continuous(self) -> None:
        frame = load_ff25_aggregated_daily(ROOT / "data/raw/100_Portfolios_10x10_Daily.zip")
        self.assertEqual(frame.shape[1], 25)
        self.assertFalse(frame.isna().any().any())
        self.assertLess(frame.index.min(), pd.Timestamp("1964-01-01"))
        self.assertLessEqual(frame.index.to_series().diff().max(), pd.Timedelta(days=7))

    def test_forward_variance_requires_all_22_returns(self) -> None:
        market = load_spx_vix(
            ROOT / "data/raw/spx_yahoo_1990_2026.json",
            ROOT / "data/raw/vix_history_1990_2026.csv",
        )
        frame = build_forecast_frame(market)
        self.assertTrue(frame["future_variance"].tail(22).isna().all())
        evaluable = frame.dropna(subset=["future_variance", "target_end"])
        self.assertTrue((evaluable["target_end"] > evaluable.index).all())

    def test_spy_total_return_and_cash_alignment(self) -> None:
        frame = build_extended_frame(
            ROOT / "data/raw/spx_yahoo_1990_2026.json",
            ROOT / "data/raw/vix_history_1990_2026.csv",
            ROOT / "data/raw/spy_yahoo_1993_2026.json",
            ROOT / "data/raw/dgs3mo_2000_2026.csv",
        )
        modern = frame.loc["2005":"2026-07-14"]
        self.assertFalse(modern[["next_spy_total_return", "cash_return"]].isna().any().any())
        self.assertTrue((modern["cash_return"] > -0.001).all())

    def test_strategy_cash_and_exposure_identity(self) -> None:
        index = pd.date_range("2020-01-01", periods=3, freq="D")
        next_return = pd.Series([0.10, -0.05, 0.02], index=index)
        cash = pd.Series([0.001, 0.001, 0.001], index=index)
        all_asset = simulate_total_return_strategy(
            pd.Series(1.0, index=index), next_return, cash, cost_bps=0.0
        )
        all_cash = simulate_total_return_strategy(
            pd.Series(0.0, index=index), next_return, cash, cost_bps=0.0
        )
        np.testing.assert_allclose(all_asset.returns.to_numpy(), next_return.to_numpy())
        np.testing.assert_allclose(all_cash.returns.to_numpy(), cash.to_numpy())

    def test_emitted_maturity_and_training_audits(self) -> None:
        allocation_path = ROOT / "results/bootstrap_dro_allocation/covariance_and_training_audit.csv"
        hedge_path = ROOT / "results/distributional_volatility/hedge_maturity_audit.csv"
        calibration_path = (
            ROOT
            / "results/distributional_volatility/calibration_maturity_and_overlap_audit.csv"
        )
        if not (allocation_path.exists() and hedge_path.exists() and calibration_path.exists()):
            self.skipTest("Run python run_all.py before testing emitted audit files.")
        allocation = pd.read_csv(allocation_path)
        hedge = pd.read_csv(hedge_path)
        calibration = pd.read_csv(calibration_path)
        self.assertTrue(allocation["strictly_past_training"].all())
        self.assertTrue(hedge["all_training_labels_matured"].all())
        self.assertTrue(calibration["all_calibration_labels_matured"].all())
        self.assertTrue(calibration["same_stream_only"].all())
        self.assertTrue(calibration["nonoverlapping_within_stream"].all())

    def test_generated_artifacts_are_nonempty(self) -> None:
        result_root = ROOT / "results"
        if not result_root.exists():
            self.skipTest("Run python run_all.py before testing generated artifacts.")
        empty = [path for path in result_root.rglob("*") if path.is_file() and path.stat().st_size == 0]
        self.assertEqual(empty, [], f"Empty generated artifacts: {empty}")

    def test_selected_allocation_weights_are_feasible(self) -> None:
        result_path = ROOT / "results/bootstrap_dro_allocation/results.json"
        weight_path = ROOT / "results/bootstrap_dro_allocation/selected_target_weights.csv"
        if not (result_path.exists() and weight_path.exists()):
            self.skipTest("Run python run_all.py before testing selected weights.")
        result = json.loads(result_path.read_text())
        cap = float(result["selected_configuration"]["maximum_weight"])
        weights = pd.read_csv(weight_path, index_col=0)
        np.testing.assert_allclose(weights.sum(axis=1).to_numpy(), 1.0, atol=1e-10)
        self.assertGreaterEqual(float(weights.min().min()), -1e-12)
        self.assertLessEqual(float(weights.max().max()), cap + 1e-10)


if __name__ == "__main__":
    unittest.main()
